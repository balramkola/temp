
#import "Inventry.h"

@implementation Inventry

-(void) initInventory{
    NSLog(@"initInventory method called");
    
    NSLog(@"inventoryResponder is not allocated, initializing it");
    _inventoryResponder = [[TSLInventoryCommand alloc] init];
    NSLog(@"inventoryResponder is  allocated in memory");
    
    _inventoryResponder.transponderReceivedDelegate = self;
    
    _inventoryResponder.captureNonLibraryResponses = YES;
    
    NSLog(@"barcodeResponder is not allocated, initializing it");
    _barcodeResponder = [[TSLBarcodeCommand alloc] init];
    NSLog(@"barcodeResponder is  allocated in memory");
    
    _barcodeResponder.captureNonLibraryResponses = YES;
    _barcodeResponder.useEscapeCharacter = TSL_TriState_YES;
    _barcodeResponder.includeDateTime = TSL_TriState_YES;
    _barcodeResponder.barcodeReceivedDelegate = self;
}

-(void)setCommander:(TSLAsciiCommander* )commander{
    _commander = commander;
}

-(void)setRfidEnabled:(bool)value{
    bool oldState = mRfidEnabled;
    mRfidEnabled = value;
    if(oldState!=value){
        if(mRfidEnabled){
            if(_commander == nil){
                NSLog(@"commander is null, unable to add inventory responder to commander");
                return;
            }
            NSLog(@"_inventoryResponder added to commander to receive tag events");
            [_commander addResponder:_inventoryResponder];
        }else{
            if(_commander == nil){
                NSLog(@"commander is null, unable to add inventory responder to commander");
                return;
            }
            NSLog(@"_inventoryResponder removed from commander to not receive tag events");
            [_commander removeResponder:_inventoryResponder];
        }
    }
}

-(void)setBarcodeEnabled:(bool)value{
    bool oldState = mBarcodeEnabled;
    mBarcodeEnabled = value;
    if(oldState!=value){
        if(mBarcodeEnabled){
            if(_commander == nil){
                NSLog(@"commander is null, unable to add barcode responder to commander");
                return;
            }
            NSLog(@"_barcodeResponder added to commander to receive barcode events");
            [_commander addResponder:_barcodeResponder];
        }else{
            if(_commander == nil){
                NSLog(@"commander is null, unable to add barcode responder to commander");
                return;
            }
            NSLog(@"_barcodeResponder removed from commander to not receive barcode events");
            [_commander removeResponder:_barcodeResponder];
        }
    }
}


-(void)setReaderConfig{
    if(_commander != nil && _commander.isConnected){
        bool rfidEnabled= mRfidEnabled;
        bool barcodeEnabled = mBarcodeEnabled;
        [self setRfidEnabled:false];
        [self setBarcodeEnabled:false];
        TSLInventoryCommand *invCommand = [self getReaderConfig];
        invCommand.takeNoAction = TSL_TriState_NO;
        [self resetDevice];
        NSLog(@"executing configuration command");
        [_commander executeCommand:invCommand];
        [self setRfidEnabled:rfidEnabled];
        [self setBarcodeEnabled:barcodeEnabled];
        return;
    }
    NSLog(@"either commander is nill or reader is not connected");
}

-(void)resetDevice{
    if(_commander != nil && _commander.isConnected){
        NSLog(@"executing factory reset command");
        TSLFactoryDefaultsCommand *fdCommand = [[TSLFactoryDefaultsCommand alloc] init];
        fdCommand.resetParameters = TSL_TriState_YES;
        [_commander executeCommand:fdCommand];
        return;
    }
    NSLog(@"either commander is nill or reader is not connected");
}


-(TSLInventoryCommand* ) getReaderConfig{
    if(_commander == nil){
        NSLog(@"commander is null, unable to getReaderConfig");
        return nil;
    }
    TSLInventoryCommand *invCommand = [[TSLInventoryCommand alloc] init];
    invCommand.includeTransponderRSSI = TSL_TriState_YES;
    invCommand.includeEPC = TSL_TriState_YES;
    invCommand.includePC = TSL_TriState_YES;
    invCommand.includeDateTime = TSL_TriState_YES;
    invCommand.includeChecksum = TSL_TriState_YES;
    invCommand.outputPower = [TSLInventoryCommand maximumOutputPower];
    
    return invCommand;
}

- (void)transponderReceived:(NSString *)epc crc:(NSNumber *)crc pc:(NSNumber *)pc rssi:(NSNumber *)rssi fastId:(NSData *)fastId moreAvailable:(BOOL)moreAvailable {
    
    NSLog(@"calling  transponder call back method");
    
    NSLog(@"epc tag value = %@",epc);
    NSLog(@"crc tag value = %@",crc);
    NSLog(@"pc tag value = %@",pc);
    NSLog(@"rssi tag value = %@",rssi);
    NSLog(@"fastId tag value = %@",fastId);
}

- (void)barcodeReceived:(NSString *)barcodeData {
    NSLog(@"detected barcode: %@",barcodeData);
}

@end
