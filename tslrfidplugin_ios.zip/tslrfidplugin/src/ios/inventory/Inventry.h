
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <TSLAsciiCommands/TSLAsciiCommands.h>


#import "Connector.h"


@interface Inventry :NSObject<TSLInventoryCommandTransponderReceivedDelegate,TSLBarcodeCommandBarcodeReceivedDelegate> {
    
    TSLInventoryCommand *_inventoryResponder;
    TSLBarcodeCommand *_barcodeResponder;
    TSLAsciiCommander *_commander;
    bool mRfidEnabled;
    bool mBarcodeEnabled;
    
}

-(void) initInventory;
-(void) setReaderConfig;
-(TSLInventoryCommand* ) getReaderConfig;
-(void) setRfidEnabled:(bool)value;
-(void) setBarcodeEnabled:(bool)value;
-(void) resetDevice;
-(void)setCommander:(TSLAsciiCommander* )commander;

@end
