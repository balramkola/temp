#import "Connector.h"

#import <TSLAsciiCommands/TSLAsciiCommands.h>
#import <TSLAsciiCommands/TSLBinaryEncoding.h>
#import <ExternalAccessory/ExternalAccessory.h>
#import <ExternalAccessory/EAAccessoryManager.h>

@implementation Connector

@synthesize connectorDelegate;

-(void) connect:(NSString *)readerAddress{
    
    NSLog(@"reader address = %@",readerAddress);
    NSArray *accessories = [[EAAccessoryManager sharedAccessoryManager]
                            connectedAccessories];
    NSLog(@"%@",accessories);
    if (accessories.count == 0) {
        NSLog(@"accessiers list is empty");
        [self onError:@"accessiers list is empty"];
        return ;
    }
    
    bool accessoryFound = false;
    for (int i = 0 ; i < [accessories count] ; i++)
    {
        accessory = [accessories objectAtIndex:i];
        if([accessory.serialNumber isEqualToString:readerAddress] ){
            accessoryFound=true;
            break;
        }
    }
    if(!accessoryFound){
        NSLog(@"reader not found in accessory list");
        [self onError:@"reader not found in accessory list"];
        return;
    }
    
    NSLog(@"accessory deatils: %@",accessory);
    NSLog(@"accessory serial number: %@", accessory.serialNumber);
    NSLog(@"accessory protocol: %@", accessory.protocolStrings);
    
    if (accessory.protocolStrings.count == 0){
        NSLog(@"reader protocol count is zero");
        [self onError:@"reader protocol count is zero"];
        return;
    }
    
    NSLog(@"Readers list size = %lu",(unsigned long)accessories.count);
    NSLog(@"Readers list = %@", accessories);
    
    if(_commander == nil){
        NSLog(@"commander is not allocated");
        _commander = [[TSLAsciiCommander alloc] init];
    }
    
    [self regStateChanges];
    
    self.readerAddress = readerAddress;
    
    if( !_commander.isConnected )
    {
        NSLog(@"reader is not connected, calling connect method");
        if([_commander connect:accessory]){
            NSLog(@"commander's connect method executed properly");
        }else{
            NSLog(@"commander's connect method executed inproperly");
        }
    }else{
        NSLog(@"reader connected");
        [self onConnected];
    }
}

-(void)regStateChanges{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onReaderStatechange) name:TSLCommanderStateChangedNotification object:_commander];
}

-(void)unRegStateChanges{
    [[NSNotificationCenter defaultCenter] valueForKey:TSLCommanderStateChangedNotification];
}

-(void)onReaderStatechange
{
    NSLog(@"onReaderStatechange function called");
    
    if(_commander != nil ){
        
        if(_commander.isConnected )
        {
            NSLog(@"reader connected");
            [self onConnected];
        }
        else
        {
            NSLog(@"reader disconnected");
            [self onDisconnected];
        }
        return;
    }
    
    NSLog(@"commander is not initialized");
    [self onError:@"commander is not initialized"];
}

-(void) disconnect{
    NSLog(@"calling disconnect method from connector");
    if(_commander != nil ){
        if(_commander.isConnected )
        {
            NSLog(@"calling commander disconnect method");
            [_commander disconnect];
        }
        else
        {
            NSLog(@"reader disconnected");
            [self onDisconnected];
        }
        return;
    }
    [self onDisconnected];
}

-(NSString *) getConnectionStatus{
    
    if(_commander == nil ){
        return @"Disonnected";
    }
    if(_commander.isConnected )
    {
        return @"Connected";
    }
    return @"Disonnected";
}

-(void) onConnected{
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onConnected];
    }
}

-(void) onDisconnected{
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onDisconnected];
    }
}

-(void) onError:(NSString *)errMsg{
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onError:errMsg];
    }
}

-(TSLAsciiCommander* )getCommander{
    return _commander;
}

@end
