
#import "TslHandler.h"

@implementation TslHandler

-(void) connect:(NSString *)readerAddress{
    readerAddress = @"1166-003793";
    NSLog(@"reder address = %@",readerAddress);
    if(connector == nil){
        
        NSLog(@"connector object is not initialized ");
        connector = [[Connector alloc]init];
        [connector setConnectorDelegate:self];
        NSLog(@"connector objcet is insalized");
    }
    NSLog(@"calling connect method");
    [connector connect:readerAddress];
}

-(void) disconnect{
    NSLog(@"TslHandler disconnect method called");
    if(connector != nil){
        [connector disconnect];
        return;
    }
    NSLog(@"Connector obj is nil");
}

-(NSString *) getConnectionStatus{
    if(connector != nil){
        return [connector getConnectionStatus];
    }
    return @"Disconnected";
}

- (void)onDisconnected {
    NSLog(@"Disconnected");
}

- (void)onConnected{
    NSLog(@"onConnected called up");
    if(connector == nil){
        NSLog(@"connector object is not initialized ");
        return;
    }
    _commander = [connector getCommander];
    if(_commander == nil){
        NSLog(@"_commander object is nil, can't proceed");
        return;
    }
    
    if(inventry == nil){
        NSLog(@"inventry object is not initialized, initializing it ");
        inventry = [[Inventry alloc]init];
        NSLog(@"inventry object is initialized ");
    }
    
    [inventry initInventory];
    [inventry setCommander:_commander];
    [inventry setRfidEnabled:true];
    [inventry setBarcodeEnabled:true];
    [inventry setReaderConfig];
}

- (void)onError:(NSString *)errMsg {
    NSLog(@"connection error = %@", errMsg);
}

@end
