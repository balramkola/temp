#import <Foundation/Foundation.h>
#import "Connector.h"
#import "Inventry.h"

#import <TSLAsciiCommands/TSLAsciiCommands.h>

@interface TslHandler :NSObject<ConnectorDelegate>{
    Connector *connector;
    Inventry *inventry;
    TSLAsciiCommander *_commander;
}

-(void) connect:(NSString *)readerAddress;
-(void) disconnect;
-(NSString *) getConnectionStatus;

@end

