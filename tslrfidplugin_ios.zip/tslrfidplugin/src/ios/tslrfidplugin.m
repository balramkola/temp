/********* tslrfidplugin.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>

#import <UIKit/UIKit.h>

#import "TslHandler.h"

@interface tslrfidplugin : CDVPlugin {
    NSString *callBackID;
    TslHandler *tslhandler;
}
- (void)initRfidReader:(CDVInvokedUrlCommand*)command;
- (void)startReaderEvents:(CDVInvokedUrlCommand*)command;
- (void)stopReaderEvents:(CDVInvokedUrlCommand*)command;
- (void)connect:(CDVInvokedUrlCommand*)command;
- (void)stopConnEvents:(CDVInvokedUrlCommand*)command;
- (void)disconnect:(CDVInvokedUrlCommand*)command;
- (void)enableTagScan:(CDVInvokedUrlCommand*)command;
- (void)enableBarcodeScan:(CDVInvokedUrlCommand*)command;
- (void)scanTags:(CDVInvokedUrlCommand*)command;
- (void)getConnectionStatus:(CDVInvokedUrlCommand*)command;
- (void)getReaderProperties:(CDVInvokedUrlCommand*)command;
@end

@implementation tslrfidplugin

-(void)viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)initRfidReader:(CDVInvokedUrlCommand*)command
{
    NSString *libstring = [command.arguments objectAtIndex:0];
    NSLog(@"initializing the lib name = %@",libstring);
    tslhandler = [[TslHandler alloc]init];
}

- (void)enableBarcodeScan:(CDVInvokedUrlCommand*)command{
    NSLog(@"enableBarcodeScan");
}

- (void)scanTags:(CDVInvokedUrlCommand*)command{
    NSLog(@"scanTags");
}

- (void)getConnectionStatus:(CDVInvokedUrlCommand*)command{
    NSLog(@"getConnectionStatus action called");
    if(tslhandler == nil){
        NSLog(@" reader library is not insalized ");
        //send library  not insilized info in ionic ui
        return;
    }
    NSLog(@"connection status: %@",[tslhandler getConnectionStatus]);
}

- (void)getReaderProperties:(CDVInvokedUrlCommand*)command{
    NSLog(@"getReaderProperties");
}

- (void)startReaderEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"startReaderEvents");
}

- (void)stopReaderEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"stopReaderEvents");
}

- (void)connect:(CDVInvokedUrlCommand*)command{
    NSLog(@"connect action called up");
    if(tslhandler == nil){
        NSLog(@"reader library is not initialized");
        //send library  not insilized info in ionic ui
    }
    else{
        //TODo checking optional value of readeraddress
        //if readeraddress is not proper then sent message to ionic ui
        NSString *readerAddress = [command.arguments objectAtIndex:0];
        if([self validation:readerAddress]){
            [tslhandler  connect:readerAddress];
        }
        else{
            NSLog(@"readeraddress is not proper then sent message to ionic ui");
            //TO DO SEND INFO TO IONOIC UI
        }
    }
}

-(bool)validation:(NSString *)readerAddress{
    if(readerAddress == nil){
        return false;
    }
    else{
        NSLog(@"readeraddress is  proper then sent to connectController method ");
        return true;
    }
}

- (void)stopConnEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"stopConnEvents");
}

- (void)disconnect:(CDVInvokedUrlCommand*)command{
    NSLog(@"disconnect action called up");
    if(tslhandler == nil){
        NSLog(@"reader library is not insalized ");
        //send library  not insilized info in ionic ui
    }
    else{
        NSLog(@"calling disconnect method");
        [tslhandler disconnect];
    }
}

- (void)enableTagScan:(CDVInvokedUrlCommand*)command{
    NSLog(@"enableTagScan");
}

@end
