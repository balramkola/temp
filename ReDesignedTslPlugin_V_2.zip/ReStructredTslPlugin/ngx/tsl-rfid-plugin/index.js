var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var TslRfidPluginOriginal = /** @class */ (function (_super) {
    __extends(TslRfidPluginOriginal, _super);
    function TslRfidPluginOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TslRfidPluginOriginal.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true }, arguments); };
    TslRfidPluginOriginal.prototype.stopConnEvents = function () { return cordova(this, "stopConnEvents", {}, arguments); };
    TslRfidPluginOriginal.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    TslRfidPluginOriginal.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true }, arguments); };
    TslRfidPluginOriginal.prototype.stopReaderEvents = function () { return cordova(this, "stopReaderEvents", {}, arguments); };
    TslRfidPluginOriginal.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    TslRfidPluginOriginal.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    TslRfidPluginOriginal.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    TslRfidPluginOriginal.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    TslRfidPluginOriginal.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", { "observable": true }, arguments); };
    TslRfidPluginOriginal.prototype.initRfidReader = function () { return cordova(this, "initRfidReader", {}, arguments); };
    TslRfidPluginOriginal.pluginName = "TslRfidPlugin";
    TslRfidPluginOriginal.plugin = "com.techm.tslrfidplugin";
    TslRfidPluginOriginal.pluginRef = "cordova.plugins.TslRfidPlugin";
    TslRfidPluginOriginal.repo = "";
    TslRfidPluginOriginal.platforms = ["Android"];
    return TslRfidPluginOriginal;
}(IonicNativePlugin));
var TslRfidPlugin = new TslRfidPluginOriginal();
export { TslRfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3RzbC1yZmlkLXBsdWdpbi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQ0EsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDOztJQWtCQyxpQ0FBaUI7Ozs7SUFLbEQsK0JBQU8sYUFBQyxhQUFxQjtJQUs3QixzQ0FBYztJQUtkLGtDQUFVO0lBT1Ysb0NBQVk7SUFLWix3Q0FBZ0I7SUFLaEIscUNBQWEsYUFBQyxLQUFjO0lBSzVCLHlDQUFpQixhQUFDLEtBQWM7SUFLaEMsZ0NBQVE7SUFLUiwyQ0FBbUI7SUFPbkIsMkNBQW1CO0lBS25CLHNDQUFjOzs7Ozs7d0JBL0VoQjtFQW9CbUMsaUJBQWlCO1NBQXZDLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQbHVnaW4sIENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuLyoqXG4gKiBAbmFtZSBUc2wgUmZpZCBQbHVnaW5cbiAqIEBkZXNjcmlwdGlvblxuICogVGhpcyBwbHVnaW4gY29ubmVjdHMgdG8gUkZJRCByZWFkZXJcbiAqIHNjYW5zIHRhZ3MgYW5kIGJhcmNvZGVcbiAqL1xuXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ1RzbFJmaWRQbHVnaW4nLFxuICBwbHVnaW46ICdjb20udGVjaG0udHNscmZpZHBsdWdpbicsXG4gIHBsdWdpblJlZjogJ2NvcmRvdmEucGx1Z2lucy5Uc2xSZmlkUGx1Z2luJyxcbiAgcmVwbzogJycsXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJ11cbn0pXG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBUc2xSZmlkUGx1Z2luIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIGNvbm5lY3QocmVhZGVyQWRkcmVzczogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBzdG9wQ29ubkV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGRpc2Nvbm5lY3QoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoe1xuICAgIG9ic2VydmFibGU6IHRydWVcbiAgfSlcbiAgcmVhZGVyRXZlbnRzKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgc3RvcFJlYWRlckV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGVuYWJsZVRhZ1NjYW4odmFsdWU6IGJvb2xlYW4pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGVuYWJsZUJhcmNvZGVTY2FuKHZhbHVlOiBib29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBzY2FuVGFncygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGdldENvbm5lY3Rpb25TdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoe1xuICAgIG9ic2VydmFibGU6IHRydWVcbiAgfSlcbiAgZ2V0UmVhZGVyUHJvcGVydGllcygpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGluaXRSZmlkUmVhZGVyKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG59XG4iXX0=