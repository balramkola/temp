import { __extends } from "tslib";
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var TslRfidPlugin = /** @class */ (function (_super) {
    __extends(TslRfidPlugin, _super);
    function TslRfidPlugin() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TslRfidPlugin.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true }, arguments); };
    TslRfidPlugin.prototype.stopConnEvents = function () { return cordova(this, "stopConnEvents", {}, arguments); };
    TslRfidPlugin.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    TslRfidPlugin.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true }, arguments); };
    TslRfidPlugin.prototype.stopReaderEvents = function () { return cordova(this, "stopReaderEvents", {}, arguments); };
    TslRfidPlugin.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    TslRfidPlugin.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    TslRfidPlugin.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    TslRfidPlugin.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    TslRfidPlugin.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", { "observable": true }, arguments); };
    TslRfidPlugin.prototype.initRfidReader = function () { return cordova(this, "initRfidReader", {}, arguments); };
    TslRfidPlugin.pluginName = "TslRfidPlugin";
    TslRfidPlugin.plugin = "com.techm.tslrfidplugin";
    TslRfidPlugin.pluginRef = "cordova.plugins.TslRfidPlugin";
    TslRfidPlugin.repo = "";
    TslRfidPlugin.platforms = ["Android"];
    TslRfidPlugin.decorators = [
        { type: Injectable }
    ];
    return TslRfidPlugin;
}(IonicNativePlugin));
export { TslRfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3RzbC1yZmlkLXBsdWdpbi9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDOztJQWtCQyxpQ0FBaUI7Ozs7SUFLbEQsK0JBQU8sYUFBQyxhQUFxQjtJQUs3QixzQ0FBYztJQUtkLGtDQUFVO0lBT1Ysb0NBQVk7SUFLWix3Q0FBZ0I7SUFLaEIscUNBQWEsYUFBQyxLQUFjO0lBSzVCLHlDQUFpQixhQUFDLEtBQWM7SUFLaEMsZ0NBQVE7SUFLUiwyQ0FBbUI7SUFPbkIsMkNBQW1CO0lBS25CLHNDQUFjOzs7Ozs7O2dCQTVEZixVQUFVOzt3QkFuQlg7RUFvQm1DLGlCQUFpQjtTQUF2QyxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUGx1Z2luLCBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbi8qKlxuICogQG5hbWUgVHNsIFJmaWQgUGx1Z2luXG4gKiBAZGVzY3JpcHRpb25cbiAqIFRoaXMgcGx1Z2luIGNvbm5lY3RzIHRvIFJGSUQgcmVhZGVyXG4gKiBzY2FucyB0YWdzIGFuZCBiYXJjb2RlXG4gKi9cblxuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdUc2xSZmlkUGx1Z2luJyxcbiAgcGx1Z2luOiAnY29tLnRlY2htLnRzbHJmaWRwbHVnaW4nLFxuICBwbHVnaW5SZWY6ICdjb3Jkb3ZhLnBsdWdpbnMuVHNsUmZpZFBsdWdpbicsXG4gIHJlcG86ICcnLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCddXG59KVxuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgVHNsUmZpZFBsdWdpbiBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcblxuICBAQ29yZG92YSh7XG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxuICB9KVxuICBjb25uZWN0KHJlYWRlckFkZHJlc3M6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgc3RvcENvbm5FdmVudHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBkaXNjb25uZWN0KCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIHJlYWRlckV2ZW50cygpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIHN0b3BSZWFkZXJFdmVudHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBlbmFibGVUYWdTY2FuKHZhbHVlOiBib29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBlbmFibGVCYXJjb2RlU2Nhbih2YWx1ZTogYm9vbGVhbik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgc2NhblRhZ3MoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBnZXRDb25uZWN0aW9uU3RhdHVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIGdldFJlYWRlclByb3BlcnRpZXMoKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBpbml0UmZpZFJlYWRlcigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxufVxuIl19