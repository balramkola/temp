module.exports = {

        initRfidReader: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'initRfidReader', []);
        },

        readerEvents: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'startReaderEvents', []);
        },

        stopReaderEvents: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'stopReaderEvents', []);
        },

        connect: function (readerAddress, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'connect', [readerAddress]);
        },

        stopConnEvents: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'stopConnEvents', []);
        },

        disconnect: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'disconnect', []);
        },

        enableTagScan: function (value, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'enableTagScan', [value]);
        },

        enableBarcodeScan: function (value, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'enableBarcodeScan', [value]);
        },

        scanTags: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'scanTags', []);
        },

        getConnectionStatus: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'getConnectionStatus', []);
        },

        getReaderProperties: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'getReaderProperties', []);
        }
};
