package com.techm.tslrfidplugin.utilities;
import java.util.Observable;

public class EventObservable<T> extends Observable {
    private T event;

    public T getValue() {
        return event;
    }

    public void setValue(T value) {
        this.event = value;
        setChanged();
        notifyObservers(value);
    }
}