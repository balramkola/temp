package com.techm.tslrfidplugin.utilities;

import android.util.Log;

import com.techm.tslrfidplugin.common.Connector;

import org.json.JSONException;
import org.json.JSONObject;

public class Util {

    private static final String LOG_TAG = Util.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";

    public static JSONObject getJson(String eventType, String eventValue) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("eventType", eventType);
            obj.put("eventValue", eventValue);
        } catch (JSONException e) {
            Log.d(LOG_TAG, LOG_PREFIX + e.getMessage(), e);
        }
        return obj;
    }
}
