package com.techm.tslrfidplugin.common;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.techm.tslrfidplugin.utilities.EventObservable;
import com.techm.tslrfidplugin.utilities.Util;
import com.uk.tsl.rfid.asciiprotocol.AsciiCommander;
import com.uk.tsl.rfid.asciiprotocol.DeviceProperties;
import com.uk.tsl.rfid.asciiprotocol.commands.BatteryStatusCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.VersionInformationCommand;
import com.uk.tsl.rfid.asciiprotocol.device.ConnectionState;
import com.uk.tsl.rfid.asciiprotocol.device.ObservableReaderList;
import com.uk.tsl.rfid.asciiprotocol.device.Reader;
import com.uk.tsl.rfid.asciiprotocol.device.ReaderManager;
import com.uk.tsl.utils.Observable;

import org.json.JSONException;
import org.json.JSONObject;

public class Connector {
    private static final String LOG_TAG = Connector.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private final String EVENT_TYPE = "connection_status";
    private final Context mContext;

    private Reader mReader = null;
    private String mReaderAddr = null;
    private boolean isRegStateEvent = false;
    private IConnStateChange mConnStateCallback = null;
    private EventObservable<ConnectionState> mConnStateLiveData = new EventObservable<>();
    private EventObservable<String> mErrorLiveData = new EventObservable<>();

    // Handle the messages broadcast from the AsciiCommander related connection state changes
    private BroadcastReceiver mCmdMsgRcvr = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (getCommander() != null) {
                Log.d(LOG_TAG, LOG_PREFIX + "TSL Reader:" + getCommander().getConnectedDeviceName() + " Connection State:" + getCommander().getConnectionState().name());
                setConnState(getCommander().getConnectionState());
            }
        }
    };

    public Connector(Context context) {
        mContext = context;
    }

    public void disconnect() {
        if (mReader != null) {
            //disconnect device
            //Log.d(LOG_TAG, LOG_PREFIX + "Reader disconnected:" + mReader.getDisplayInfoLine());
            //sendEvent("Reader disconnected:" + mReader.getDisplayInfoLine());
            mReader.disconnect();
            mReader = null;
            if (getCommander() != null) {
                getCommander().setReader(mReader);
            }
            mReaderAddr = null;
        }
        unRegStateChanges();
    }

    // connects TSL reader via usb
    /*public void connect() {
        regConnectionStateChanges();
        AutoSelectReader(true);
    }*/

    // connects TSL reader via bluetooth
    public String connect(String deviceAddress) {

        if (getCommander() == null) {
            setError("TSL library is not initialized");
            Log.d(LOG_TAG, LOG_PREFIX + "TSL library is not initialized");
            return "";
        }

        if (deviceAddress == null || deviceAddress.isEmpty()) {
            setError("empty device address");
            Log.d(LOG_TAG, LOG_PREFIX + "empty device address");
            return "";
        }

        // Update the ReaderList which will add any unknown reader, firing events appropriately
        ReaderManager.sharedInstance().updateList();

        ObservableReaderList readerList = ReaderManager.sharedInstance().getReaderList();
        if (readerList.list().size() >= 1) {
            Log.d(LOG_TAG, LOG_PREFIX + "TSL lib detected ReaderList size is: " + readerList.list().size());

            for (Reader reader : readerList.list()) {
//                Log.d(LOG_TAG, LOG_PREFIX + "Reader display name:"+reader.getDisplayName());
//                Log.d(LOG_TAG, LOG_PREFIX + "Reader serial name:"+reader.getSerialNumber());
//                Log.d(LOG_TAG, LOG_PREFIX + "Reader MAC Address:"+reader.getDisplayInfoLine().trim();
//                Log.d(LOG_TAG, LOG_PREFIX + "device Address:"+deviceAddress);
                //"1166-003793"
                if (reader.getDisplayInfoLine() != null && reader.getDisplayInfoLine().contains(deviceAddress)) {

                    Log.d(LOG_TAG, LOG_PREFIX + "found TSL reader in the discovered list");
                    mReaderAddr = deviceAddress;
                    // Register to receive notifications from the AsciiCommander
                    regStateChanges();
                    connectToReader(reader);
                    break;
                }
            }
            if (mReader == null) {
                Log.d(LOG_TAG, LOG_PREFIX + "unable to find " + deviceAddress + " TSL Reader, please check device address and if it is turned on and paired");
                setError("Unable to find device near by, please check device address and if it is turned on and paired");
            }
        } else {
            Log.d(LOG_TAG, LOG_PREFIX + "TSL lib ObservableReaderList size is zero");
            setError("no nearby device found");
            return "";
        }
        return "";
    }

    public boolean regStateChanges() {
        if (mContext == null) {
            Log.d(LOG_TAG, LOG_PREFIX + "unable to get Context");
            setError("unable to get Context");
            return false;
        }

        if (!isRegStateEvent) {
            LocalBroadcastManager.getInstance(mContext).registerReceiver(mCmdMsgRcvr, new IntentFilter(AsciiCommander.STATE_CHANGED_NOTIFICATION));
            isRegStateEvent = true;
        }

        // Add observers for changes
        if (ReaderManager.sharedInstance() != null) {
            ReaderManager.sharedInstance().getReaderList().readerAddedEvent().addObserver(mAddedObserver);
            ReaderManager.sharedInstance().getReaderList().readerUpdatedEvent().addObserver(mUpdatedObserver);
            ReaderManager.sharedInstance().getReaderList().readerRemovedEvent().addObserver(mRemovedObserver);
        }
        return true;
    }

    public void unRegStateChanges() {
        if (mContext == null) {
            Log.d(LOG_TAG, LOG_PREFIX + "unable to get context");
            setError("unable to get context");
            return;
        }

        if (isRegStateEvent) {
            LocalBroadcastManager.getInstance(mContext).unregisterReceiver(mCmdMsgRcvr);
            isRegStateEvent = false;
        }

        // Remove observers for changes
        ReaderManager.sharedInstance().getReaderList().readerAddedEvent().removeObserver(mAddedObserver);
        ReaderManager.sharedInstance().getReaderList().readerUpdatedEvent().removeObserver(mUpdatedObserver);
        ReaderManager.sharedInstance().getReaderList().readerRemovedEvent().removeObserver(mRemovedObserver);
    }

    protected void connectToReader(Reader reader) {

        Log.d(LOG_TAG, LOG_PREFIX + "connectToReader called up");
        mReader = reader;
        if (mReader.isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "Connected to Reader:" + mReader.getDisplayInfoLine());
            setConnState(ConnectionState.CONNECTED);
            return;
        }
        if (mReader.isConnecting()) {
            Log.d(LOG_TAG, LOG_PREFIX + "Connecting... to Reader:" + mReader.getDisplayInfoLine());
            setConnState(ConnectionState.CONNECTING);
            return;
        }

        if (getCommander() != null) {
            getCommander().setReader(mReader);
        }
        mReader.connect();
        //mReader.connect(TransportType.BLUETOOTH);
    }

    private AsciiCommander getCommander() {
        return AsciiCommander.sharedInstance();
    }

    //----------------------------------------------------------------------------------------------
    // ReaderList Observers
    //----------------------------------------------------------------------------------------------
    private Observable.Observer<Reader> mAddedObserver = (observable, reader) -> {
        // See if this newly added Reader should be used
        Log.d(LOG_TAG, LOG_PREFIX + "Reader Added Observer called up");
        if (mReaderAddr != null && !mReaderAddr.isEmpty()) {
            // set Reader to previously disconnected Reader, if the connection type is BT
            if (mReaderAddr.equals(reader.getDisplayInfoLine())) {
                connectToReader(reader);
            }
        }
    };

    private Observable.Observer<Reader> mUpdatedObserver = (observable, reader) -> {
        Log.d(LOG_TAG, LOG_PREFIX + "Reader Updated Observer called up");
        // Is this a change to the last actively disconnected reader
        if (mReaderAddr != null && !mReaderAddr.isEmpty()) {
            // set Reader to previously disconnected Reader
            if (mReaderAddr.equals(reader.getDisplayInfoLine())) {
                connectToReader(reader);
            }
        }
    };

    private Observable.Observer<Reader> mRemovedObserver = (observable, reader) -> {
        Log.d(LOG_TAG, LOG_PREFIX + "Reader Removed Observer called up");
        if (mReaderAddr != null && !mReaderAddr.isEmpty()) {
            if (mReaderAddr.equals(reader.getDisplayInfoLine())) {
                setConnState(ConnectionState.DISCONNECTED);
                Log.d(LOG_TAG, LOG_PREFIX + "Reader disconnected:" + mReader.getDisplayInfoLine());
                mReader = null;
                if (getCommander() != null) {
                    getCommander().setReader(mReader);
                }
            }
        }
    };

    public JSONObject getReaderInfo() {
        JSONObject readerInfo = new JSONObject();

        if (mReader != null) {
            DeviceProperties deviceProps = mReader.getDeviceProperties();
            VersionInformationCommand verionInfoCmd = deviceProps.getInformationCommand();

            try {
                readerInfo.put("MaximumCarrierPower", deviceProps.getMaximumCarrierPower());
                readerInfo.put("MinimumCarrierPower", deviceProps.getMinimumCarrierPower());
                readerInfo.put("AntennaSerialNumber", verionInfoCmd.getAntennaSerialNumber());
                readerInfo.put("AsciiProtocol", verionInfoCmd.getAsciiProtocol());
                readerInfo.put("BluetoothAddress", verionInfoCmd.getBluetoothAddress());
                readerInfo.put("BootloaderVersion", verionInfoCmd.getBootloaderVersion());
                readerInfo.put("FirmwareVersion", verionInfoCmd.getFirmwareVersion());
                readerInfo.put("Manufacturer", verionInfoCmd.getManufacturer());
                readerInfo.put("BluetoothVersion", verionInfoCmd.getBluetoothVersion());
                readerInfo.put("RadioFirmwareVersion", verionInfoCmd.getRadioFirmwareVersion());
                readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
                readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
                readerInfo.put("RadioSerialNumber", verionInfoCmd.getRadioSerialNumber());
                readerInfo.put("SerialNumber", verionInfoCmd.getSerialNumber());

                BatteryStatusCommand bCommand = BatteryStatusCommand.synchronousCommand();
                getCommander().executeCommand(bCommand);
                readerInfo.put("BatteryLevel", bCommand.getBatteryLevel());
            } catch (JSONException e) {
                return new JSONObject();
            }

        }
        return readerInfo;
    }

    protected JSONObject getFormattedEvent(String eventValue) {
        return Util.getJson(EVENT_TYPE, eventValue);
    }

    public ConnectionState getReaderConnState() {
        if (getCommander() == null) {
            return ConnectionState.UNDEFINED;
        }
        switch (getCommander().getConnectionState()) {
            case CONNECTED:
                Log.d(LOG_TAG, LOG_PREFIX + "connected to reader:" + getCommander().getConnectedDeviceName());
                return ConnectionState.CONNECTED;
            case CONNECTING:
                Log.d(LOG_TAG, LOG_PREFIX + "connecting... to reader:" + getCommander().getConnectedDeviceName());
                return ConnectionState.CONNECTING;
            case DISCONNECTED:
                Log.d(LOG_TAG, LOG_PREFIX + "disconnected to reader:" + getCommander().getConnectedDeviceName());
                return ConnectionState.DISCONNECTED;
            case LOST:
                Log.d(LOG_TAG, LOG_PREFIX + "lost connection to reader:" + getCommander().getConnectedDeviceName());
                return ConnectionState.DISCONNECTED;
            case INTERRUPTED:
                Log.d(LOG_TAG, LOG_PREFIX + "interrupted connection to reader:" + getCommander().getConnectedDeviceName());
                return ConnectionState.DISCONNECTED;
            default:
                Log.d(LOG_TAG, LOG_PREFIX + "unable to get Connection state" + getCommander().getConnectedDeviceName());
                return ConnectionState.UNDEFINED;
        }

    }

    private void setConnState(ConnectionState state) {
        if (null != mConnStateCallback) {
            mConnStateCallback.onConnStateChange(state);
        }
    }

    private void setError(String errMsg) {
        if (null != mConnStateCallback) {
            mConnStateCallback.onError(errMsg);
        }
    }

    public void setConnStateCallback(IConnStateChange connStateCallback) {
        mConnStateCallback = connStateCallback;
    }

    public interface IConnStateChange {
        void onConnStateChange(ConnectionState connectionState);

        void onError(String errMsg);
    }

}
