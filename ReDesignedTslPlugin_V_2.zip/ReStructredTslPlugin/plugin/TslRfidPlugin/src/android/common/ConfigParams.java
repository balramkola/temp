package com.techm.tslrfidplugin.common;

public class ConfigParams {
    boolean enableRfid=true;
    boolean enableBarcode=true;
    String deviceAddress="";
}
