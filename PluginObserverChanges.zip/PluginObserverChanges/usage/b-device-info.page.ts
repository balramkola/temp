import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BDevice } from '../models/bluetooth-device';
import { TslRfidPlugin } from '@ionic-native/tsl-rfid-plugin/ngx';

@Component({
  selector: 'app-b-device-info',
  templateUrl: './b-device-info.page.html',
  styleUrls: ['./b-device-info.page.scss'],
})
export class BDeviceInfoPage implements OnInit {

  PREFIX_LOG: string = "IONIC UI: ";
  bDeviceInfo:BDevice;
  eventsTextView: string = "";
  readerAddress: string = "";
  enable: boolean = true;
  tagList: string[] = [];
  barcodeList: string[] = [];
  connectObserver: any;
  readerEventsObserver: any;

  constructor(private route: ActivatedRoute, private router: Router,private tslRfidPlugin:TslRfidPlugin) {
    this.route.queryParams.subscribe(params => {
      if (params && params.special) {
        this.bDeviceInfo = JSON.parse(params.special);
        this.readerAddress = this.bDeviceInfo.address;
        //this.bDeviceInfo.paired = false;
        console.log(this.bDeviceInfo);
        //TODO identify which library to use either TSL or Zebra
        this.subscribeReaderEvents();
        this.initRfidReader();
      }
    });
  }
  ngOnInit(): void {
    //throw new Error('Method not implemented.');
  }

  initRfidReader() {
    this.tslRfidPlugin.initRfidReader().then(result => {
      console.log(this.PREFIX_LOG + result);
    }).catch(err => alert('Error : ' + err));
  }

  subscribeReaderEvents(){
    console.log(this.PREFIX_LOG + 'Subscribing to reader events');
      this.readerEventsObserver=this.tslRfidPlugin.readerEvents().subscribe((info) => {
        console.log(this.PREFIX_LOG + 'received event from plugin code');
        if(info == null){
          return;
        }
      console.log(this.PREFIX_LOG + 'received event from plugin code');
      console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);

      if(info.eventType == "tagData"){
        this.tagList.push(info.eventValue);
      }else
        if(info.eventType == "barcodeData"){
          this.barcodeList.push(info.eventValue);
      }else{
        this.eventsTextView = info.eventValue;
      }

    });
  }

  unSubscribeReaderEvents(){
    this.readerEventsObserver.unsubscribe();
  }

  connect() {
    console.log(this.PREFIX_LOG + 'connect method called');
    //use setEnableTagScan() to get Tag scan events from Plugin code
    this.setEnableTagScan(true);
    this.connectObserver=this.tslRfidPlugin.connect(this.readerAddress).subscribe(connectionStatus => {
      console.log(this.PREFIX_LOG + 'TSL Reader connection status:'+connectionStatus);
      // switch(connectionStatus){
      //   case "Connected":
      //   case "Connecting":
      //   case "disconnected":
      //   default
      // }
    });

    //for unssubscribe use following
    //this.connectObserver.unsubscribe();
  }

  disconnect() {
    console.log(this.PREFIX_LOG + 'disconnect method called');
    this.tslRfidPlugin.disconnect().then(result => {
      console.log(this.PREFIX_LOG + 'status:' + result);
      alert(result);
    }).catch(err => alert('Error : ' + err));
  }

  clear(){
    this.tagList = [];
    this.barcodeList = [];
  }

  setEnableTagScan(value: boolean) {
    console.log(this.PREFIX_LOG + 'setEnableTagScan method called');
    this.tslRfidPlugin.enableTagScan(value).then(result => {
      console.log(this.PREFIX_LOG + 'status:' + result);
    }).catch(err => alert('Error : ' + err));
  }

  setEnableBarcodeScan(value: boolean) {
    console.log(this.PREFIX_LOG + 'setEnableBarcodeScan method called');
    this.tslRfidPlugin.enableBarcodeScan(value).then(result => {
      console.log(this.PREFIX_LOG + 'status:' + result);
      //alert(result);
    }).catch(err => alert('Error : ' + err));
  }

  getConnectionStatus() {
    console.log(this.PREFIX_LOG + 'getConnectionStatus method called');
    this.tslRfidPlugin.getConnectionStatus().then(result => {
      console.log(this.PREFIX_LOG + 'status:' + result);
      alert(result);
    }).catch(err => alert('Error : ' + err));
  }

  getReaderInfo() {
    console.log(this.PREFIX_LOG + 'getReaderInfo method called');
    this.tslRfidPlugin.getReaderProperties().then(result => {
      console.log(this.PREFIX_LOG + 'Reader info:' + result);
      //alert(result);
    }).catch(err => alert('Error : ' + err));
  }

  scanTags() {
    console.log(this.PREFIX_LOG + 'scanTags method called');
    this.tslRfidPlugin.scanTags().then(result => {
      console.log(this.PREFIX_LOG + 'scanTags command status:' + result);
      //alert(result);
    }).catch(err => alert('Error : ' + err));
  }

}
