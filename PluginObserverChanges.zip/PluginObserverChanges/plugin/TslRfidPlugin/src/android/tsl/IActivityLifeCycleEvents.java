package com.techm.tslrfidplugin.tsl;

public interface IActivityLifeCycleEvents {
	void onCreate();
	void onStart();
	void onResume();
	void onPause();
	void onStop();
	void onDestroy();
   }