package com.techm.tslrfidplugin.tsl;

import java.util.Locale;

import android.util.Log;

import com.techm.tslrfidplugin.tsl.ModelBase;
import com.uk.tsl.rfid.asciiprotocol.commands.BarcodeCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.FactoryDefaultsCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.InventoryCommand;
import com.uk.tsl.rfid.asciiprotocol.enumerations.TriState;
import com.uk.tsl.rfid.asciiprotocol.responders.IBarcodeReceivedDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.ICommandResponseLifecycleDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.ITransponderReceivedDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.TransponderData;
import com.uk.tsl.utils.HexEncoding;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class InventoryModel extends ModelBase
{

	// Control 
	private boolean mAnyTagSeen;
	private boolean mEnabled;
	public boolean enabled() { return mEnabled; }

	public void setEnabled(boolean state)
	{
		Log.d("Ballu","needed InventoryModel setEnabled called with:"+ state);
		boolean oldState = mEnabled;
		mEnabled = state;

		// Update the commander for state changes
		if(oldState != state) {
			if( mEnabled ) {
				Log.d("Ballu","needed InventoryModel Listen for transponders");
				// Listen for transponders
				getCommander().addResponder(mInventoryResponder);
				// Listen for barcodes
				getCommander().addResponder(mBarcodeResponder);
			} else {
				Log.d("Ballu","needed InventoryModel Stop listening for transponders");
				// Stop listening for transponders
				getCommander().removeResponder(mInventoryResponder);
				// Stop listening for barcodes
				getCommander().removeResponder(mBarcodeResponder);
			}
			
		}
	}

	// The command to use as a responder to capture incoming inventory responses
	private InventoryCommand mInventoryResponder;
	// The command used to issue commands
	private InventoryCommand mInventoryCommand;

	// The command to use as a responder to capture incoming barcode responses
	private BarcodeCommand mBarcodeResponder;
	
	// The inventory command configuration
	public InventoryCommand getCommand() { return mInventoryCommand; }

	public InventoryModel()
	{
		Log.d("Ballu","needed InventoryModel 1");
		// This is the command that will be used to perform configuration changes and inventories
		mInventoryCommand = new InventoryCommand();
        mInventoryCommand.setResetParameters(TriState.YES);
		// Configure the type of inventory
		mInventoryCommand.setIncludeTransponderRssi(TriState.YES);
		mInventoryCommand.setIncludeChecksum(TriState.YES);
        mInventoryCommand.setIncludePC(TriState.YES);
		mInventoryCommand.setIncludeDateTime(TriState.YES);
		mInventoryCommand.setIncludeTransponderRssi(TriState.YES);
        mInventoryCommand.setIncludeChecksum(TriState.YES);
        mInventoryCommand.setIncludePC(TriState.YES);
        mInventoryCommand.setIncludeDateTime(TriState.YES);
        mInventoryCommand.setIncludePhase(TriState.YES);
        mInventoryCommand.setIncludeEpc(TriState.YES);
        mInventoryCommand.setIncludeChannelFrequency(TriState.YES);
        mInventoryCommand.setIncludeIndex(TriState.YES);

		Log.d("Ballu","needed InventoryModel 2");

		// Use an InventoryCommand as a responder to capture all incoming inventory responses
		mInventoryResponder = new InventoryCommand();

		// Also capture the responses that were not from App commands 
		mInventoryResponder.setCaptureNonLibraryResponses(true);
		Log.d("Ballu","needed InventoryModel 3");

		// Notify when each transponder is seen
		mInventoryResponder.setTransponderReceivedDelegate(new ITransponderReceivedDelegate() {

			int mTagsSeen = 0;
			@Override
			public void transponderReceived(TransponderData transponder, boolean moreAvailable) {
				mAnyTagSeen = true;
                Log.d("InventoryModel","detected RFID tag");
                Map<String,String> map=new HashMap<String,String>();
                map.put("EPC",transponder.getEpc());
                //map.put("TidData",""+transponder.getTidData() == null ? "" : HexEncoding.bytesToString(transponder.getTidData()));
                map.put("Rssi",""+transponder.getRssi());
                //map.put("CRC",""+transponder.getCrc());
                //map.put("PC",""+transponder.getPc());
                //map.put("ReadData",""+transponder.getReadData() == null ? "" : HexEncoding.bytesToString(transponder.getReadData()));
                map.put("AccessErrorCode",""+transponder.getAccessErrorCode());
                //map.put("ChannelFrequency",""+transponder.getChannelFrequency());
                map.put("Timestamp",""+transponder.getTimestamp());
                //map.put("Index",""+transponder.getIndex());
                //map.put("Phase",""+transponder.getPhase());
                JSONObject tagInfo = new JSONObject(map);
                Log.d("InventoryModel","Tag info:"+tagInfo.toString());
                sendMessageNotification(tagInfo.toString());
                //String tidMessage = transponder.getTidData() == null ? "" : HexEncoding.bytesToString(transponder.getTidData());
                //String infoMsg = String.format(Locale.US, "\nRSSI: %d  PC: %04X  CRC: %04X", transponder.getRssi(), transponder.getPc(), transponder.getCrc());
                //Log.d(LOG_TAG, LOG_PREFIX + "detected RFID tag EPC:" + transponder.getEpc());
                //sendTagEvent("EPC: " + transponder.getEpc() + infoMsg + "\nTID: " + tidMessage + "\n# " + mTagsSeen);
				mTagsSeen++;
				if( !moreAvailable) {
					sendMessageNotification("");
					Log.d("TagCount",String.format("Tags seen: %s", mTagsSeen));
				}
			}
		});

		mInventoryResponder.setResponseLifecycleDelegate( new ICommandResponseLifecycleDelegate() {
			
			@Override
			public void responseEnded() {
				Log.d("Ballu","needed InventoryModel response ended");
				if( !mAnyTagSeen && mInventoryCommand.getTakeNoAction() != TriState.YES) {
					sendMessageNotification("No transponders seen");
				}
                mInventoryCommand.setTakeNoAction(TriState.NO);
            }
			
			@Override
			public void responseBegan() {
				mAnyTagSeen = false;
				Log.d("Ballu","needed InventoryModel response began");
			}
		});

		// This command is used to capture barcode responses
		mBarcodeResponder = new BarcodeCommand();
		mBarcodeResponder.setCaptureNonLibraryResponses(true);
		mBarcodeResponder.setUseEscapeCharacter(TriState.YES);
		mBarcodeResponder.setBarcodeReceivedDelegate(new IBarcodeReceivedDelegate() {
			@Override
			public void barcodeReceived(String barcode) {
				sendMessageNotification("BC: " + barcode);
			}
		});

	
	}

	//
	// Reset the reader configuration to default command values
	//
	public void resetDevice()
	{
		if(getCommander().isConnected()) {
            FactoryDefaultsCommand fdCommand = new FactoryDefaultsCommand();
            fdCommand.setResetParameters(TriState.YES);
            getCommander().executeCommand(fdCommand);
		}
	}
	
	//
	// Update the reader configuration from the command
	// Call this after each change to the model's command
	//
	public void updateConfiguration()
	{
		if(getCommander().isConnected()) {
			mInventoryCommand.setTakeNoAction(TriState.YES);
			getCommander().executeCommand(mInventoryCommand);
		}
	}
	
	//
	// Perform an inventory scan with the current command parameters
	//
	public void scan()
	{
		Log.d("Ballu","needed InventoryModel scan called");
		testForAntenna();
		if(getCommander().isConnected()) {
			Log.d("Ballu","needed InventoryModel in scan menthod, isConnected success");
			mInventoryCommand.setTakeNoAction(TriState.NO);
			getCommander().executeCommand(mInventoryCommand);
			Log.d("Ballu","needed InventoryModel scan execute method called");
		}
	}

	public void setCallback(ResponseHandlerInterface callback){
		mEventsCallback = callback;
	}

	// public void setHandler(ResponseHandlerInterface callbackHandler)
	// {
	// 	mCallbackHandler = callbackHandler;
	// }

	//
	// Test for the presence of the antenna
	//
	public void testForAntenna()
	{
		Log.d("Ballu","needed InventoryModel test for antenna called");
		if(getCommander().isConnected()) {
			InventoryCommand testCommand = InventoryCommand.synchronousCommand();
			testCommand.setTakeNoAction(TriState.YES);
			getCommander().executeCommand(testCommand);
			if( !testCommand.isSuccessful() ) {
				Log.d("Ballu","needed InventoryModel test for antenna called getCommander().isConnected() SUCCESS");
				sendMessageNotification("ER:Error! Code: " + testCommand.getErrorCode() + " " + testCommand.getMessages().toString());
			}
		}else{
			Log.d("Ballu","needed InventoryModel test for antenna called getCommander().isConnected() FAILED");
		}
	}

	public interface ResponseHandlerInterface {
		void handleTagdata(String tagData);
	}
}
