package com.techm.tslrfidplugin;

import android.os.AsyncTask;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import android.util.Log;
import org.apache.cordova.PluginResult;
import org.apache.cordova.CordovaWebView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.CountDownTimer;
import android.content.Context;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
//TSL
import com.uk.tsl.rfid.asciiprotocol.device.ConnectionState;
import com.techm.tslrfidplugin.tsl.InventoryModel;
import com.techm.tslrfidplugin.tsl.IActivityLifeCycleEvents;
import com.uk.tsl.rfid.asciiprotocol.AsciiCommander;
import com.uk.tsl.rfid.asciiprotocol.DeviceProperties;
import com.uk.tsl.rfid.asciiprotocol.commands.FactoryDefaultsCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.BatteryStatusCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.VersionInformationCommand;
import com.uk.tsl.rfid.asciiprotocol.device.ConnectionState;
import com.uk.tsl.rfid.asciiprotocol.device.IAsciiTransport;
import com.uk.tsl.rfid.asciiprotocol.device.ObservableReaderList;
import com.uk.tsl.rfid.asciiprotocol.device.Reader;
import com.uk.tsl.rfid.asciiprotocol.device.ReaderManager;
import com.uk.tsl.rfid.asciiprotocol.device.TransportType;
import com.uk.tsl.rfid.asciiprotocol.enumerations.QuerySession;
import com.uk.tsl.rfid.asciiprotocol.enumerations.TriState;
import com.uk.tsl.rfid.asciiprotocol.parameters.AntennaParameters;
import com.uk.tsl.rfid.asciiprotocol.responders.LoggerResponder;
import com.uk.tsl.utils.Observable;


/**
 * This class echoes a string called from JavaScript.
 */
public class TslRfidPlugin extends CordovaPlugin implements InventoryModel.ResponseHandlerInterface,IActivityLifeCycleEvents{

    private static final String LOG_TAG = "TslRfidPlugin";
    private static final String LOG_PREFIX = "PLUGIN: ";
    private CallbackContext mConnectCallback;
    private CallbackContext mReaderEventsCallbackContext;
    

    //TSL
    // All of the reader inventory tasks are handled by this class
    private InventoryModel mModel;
    // The Reader currently in use
    private Reader mReader = null;
    private Reader mLastUserDisconnectedReader = null;
    private boolean mIsSelectingReader = false;
    private Context context = null;

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.mConnectCallback = null;
        this.mReaderEventsCallbackContext =null;
    }

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        
        boolean validAction = true;

        if(action.equals("initRfidReader")) {

            Log.d(LOG_TAG, LOG_PREFIX + "initializing RFID Reader");
            context = cordova.getActivity().getApplicationContext();
            new AsyncTSLinit().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, null);

        }else if (action.equals("startReaderEvents")) {

             Log.d(LOG_TAG, LOG_PREFIX + "startReaderEvents called");
            this.mReaderEventsCallbackContext = callbackContext;
            PluginResult result = new PluginResult(PluginResult.Status.OK);
            result.setKeepCallback(true);
            callbackContext.sendPluginResult(result);

        }else if (action.equals("unSubscribeReaderEvents")) {

            Log.d(LOG_TAG, LOG_PREFIX + "unSubscribeReaderEvents action called");
            mReaderEventsCallbackContext = null;
            callbackContext.success();

        }else if (action.equals("connect")) {

            Log.d(LOG_TAG, LOG_PREFIX + "connect action called");
            //callbackContext.error("Device does not support Bluetooth");
            if (BluetoothAdapter.getDefaultAdapter() == null) {
                PluginResult result = new PluginResult(PluginResult.Status.OK,"Device does not support Bluetooth");
                result.setKeepCallback(false);
                callbackContext.sendPluginResult(result);
                return false;
            }
            Log.d(LOG_TAG, LOG_PREFIX + "device address:"+args.getString(0));
            
            String macAddress = args.getString(0);
            BluetoothDevice device = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(macAddress);

            if (device != null) {
                mConnectCallback = callbackContext;
                connect(args.getString(0));

                PluginResult result = new PluginResult(PluginResult.Status.NO_RESULT);
                result.setKeepCallback(true);
                callbackContext.sendPluginResult(result);

            } else {
                PluginResult result = new PluginResult(PluginResult.Status.OK,"Could not connect to " + macAddress);
                result.setKeepCallback(false);
                callbackContext.sendPluginResult(result);
            }

        }else if (action.equals("unSubscribeConnect")) {

            Log.d(LOG_TAG, LOG_PREFIX + "unSubscribeConnect action called");
            mConnectCallback = null;
            callbackContext.success();

        }else if (action.equals("disconnect")) {    

            if(mModel!=null){
                //unregister for tag events
                mModel.setEnabled(false);
                Log.d(LOG_TAG, LOG_PREFIX + "unregistering for tag events");
            }

            if(mReader!=null){
                //disconnect device
                mReader.disconnect();
                Log.d(LOG_TAG, LOG_PREFIX + "disconnecting reader device");
                getCommander().setReader(null);
            }
            //unregister to receive notifications from the AsciiCommander
            // LocalBroadcastManager.getInstance(cordova.getActivity()).unregisterReceiver(mCommanderMessageReceiver);
            // Log.d(LOG_TAG, LOG_PREFIX + "unregistering connection state receiver");

        }else if (action.equals("getReaderProperties")) {       

            if(mReader!=null){
                try{
                    //sendRfidEvent(getJson("ReaderInfo", getReaderInfo().toString()), true);
                    callbackContext.success(getJson("ReaderInfo", getReaderInfo().toString()).toString());
                }catch(JSONException e){
                    //TODO
                }
            }

        }else if (action.equals("getConnectionStatus")) {   

            getReaderState(callbackContext);

        }else if (action.equals("enableTagScan")) {     

            if(mModel!=null){
                //register for tag events
                Log.d(LOG_TAG, LOG_PREFIX + "registering for tag events");
                mModel.setEnabled(args.getBoolean(0));
            }

        }else if (action.equals("enableBarcodeScan")) {     

            if(mModel!=null){
                //unregister for tag events
                Log.d(LOG_TAG, LOG_PREFIX + "unregistering for tag events");
                //mModel.setEnabled(false); 
                //TODO add barcode
            }

        }else if (action.equals("scanTags")) {    

            if(mModel!=null){
                 Log.d(LOG_TAG, LOG_PREFIX + "excecuting scan command for tag detection");
                mModel.scan();
            }

        }else{
            validAction = false;
        }
        return validAction;
    }

    //TSL
    /**
     * @return the current AsciiCommander
     */
    protected AsciiCommander getCommander()
    {
        return AsciiCommander.sharedInstance();
    }

    //----------------------------------------------------------------------------------------------
    // ReaderList Observers
    //----------------------------------------------------------------------------------------------
    Observable.Observer<Reader> mAddedObserver = new Observable.Observer<Reader>()
    {
        @Override
        public void update(Observable<? extends Reader> observable, Reader reader)
        {
            // See if this newly added Reader should be used
            Log.d(LOG_TAG, LOG_PREFIX + "mAddedObserver");
            AutoSelectReader(true);
        }
    };

    Observable.Observer<Reader> mUpdatedObserver = new Observable.Observer<Reader>()
    {
        @Override
        public void update(Observable<? extends Reader> observable, Reader reader)
        {
            Log.d(LOG_TAG, LOG_PREFIX + "mUpdatedObserver");
            // Is this a change to the last actively disconnected reader
            if( reader == mLastUserDisconnectedReader )
            {
                // Things have changed since it was actively disconnected so
                // treat it as new
                mLastUserDisconnectedReader = null;
            }

            // Was the current Reader disconnected i.e. the connected transport went away or disconnected
            if( reader == mReader && !reader.isConnected() )
            {
                // No longer using this reader
                mReader = null;

                // Stop using the old Reader
                getCommander().setReader(mReader);
                Log.d(LOG_TAG, LOG_PREFIX + "Stop using the old Reader");
            }
            else
            {
                // See if this updated Reader should be used
                // e.g. the Reader's USB transport connected
                AutoSelectReader(true);
            }
        }
    };

    Observable.Observer<Reader> mRemovedObserver = new Observable.Observer<Reader>()
    {
        @Override
        public void update(Observable<? extends Reader> observable, Reader reader)
        {
            // Is this a change to the last actively disconnected reader
            if( reader == mLastUserDisconnectedReader )
            {
                // Things have changed since it was actively disconnected so
                // treat it as new
                mLastUserDisconnectedReader = null;
            }

            // Was the current Reader removed
            if( reader == mReader)
            {
                mReader = null;

                // Stop using the old Reader
                getCommander().setReader(mReader);
            }
        }
    };

    private void AutoSelectReader(boolean attemptReconnect)
    {
        Log.d(LOG_TAG, LOG_PREFIX + "AutoSelectReader called up");
        ObservableReaderList readerList = ReaderManager.sharedInstance().getReaderList();
        Reader usbReader = null;
        if( readerList.list().size() >= 1)
        {
            // Currently only support a single USB connected device so we can safely take the
            // first CONNECTED reader if there is one
            for (Reader reader : readerList.list())
            {
                if (reader.hasTransportOfType(TransportType.USB))
                {
                    usbReader = reader;
                    break;
                }
            }
        }

        if( mReader == null )
        {
            if( usbReader != null && usbReader != mLastUserDisconnectedReader)
            {
                // Use the Reader found, if any
                mReader = usbReader;
                getCommander().setReader(mReader);
            }
        }
        else
        {
            // If already connected to a Reader by anything other than USB then
            // switch to the USB Reader
            IAsciiTransport activeTransport = mReader.getActiveTransport();
            if ( activeTransport != null && activeTransport.type() != TransportType.USB && usbReader != null)
            {
                mReader.disconnect();
                mReader = usbReader;
                // Use the Reader found, if any
                getCommander().setReader(mReader);
            }
        }

        // Reconnect to the chosen Reader
        if( mReader != null
                && !mReader.isConnecting()
                && (mReader.getActiveTransport()== null || mReader.getActiveTransport().connectionStatus().value() == ConnectionState.DISCONNECTED))
        {
            getCommander().setReader(mReader);
            // Attempt to reconnect on the last used transport unless the ReaderManager is cause of OnPause (USB device connecting)
            if( attemptReconnect )
            {
                if( mReader.allowMultipleTransports() || mReader.getLastTransportType() == null )
                {
                    // Reader allows multiple transports or has not yet been connected so connect to it over any available transport
                    mReader.connect();
                    mModel.setEnabled(true);
                }
                else
                {
                    // Reader supports only a single active transport so connect to it over the transport that was last in use
                    mReader.connect(mReader.getLastTransportType());
                }
            }
        }
    }

    /**
     * Creates a JSONObject with the countdown timer information
     * 
     * @return a JSONObject containing the timer information
     */
    private JSONObject getJson(String eventType, String eventValue) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("eventType", eventType);
            obj.put("eventValue", eventValue);
        } catch (JSONException e) {
            Log.d(LOG_TAG, LOG_PREFIX + e.getMessage(), e);
        }
        return obj;
    }

    private void sendRfidEvent(JSONObject info, boolean keepCallback) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendRfidEvent called");
        if (this.mReaderEventsCallbackContext != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "mReaderEventsCallbackContext is not null");
            PluginResult result = new PluginResult(PluginResult.Status.OK, info);
            result.setKeepCallback(keepCallback);
            this.mReaderEventsCallbackContext.sendPluginResult(result);
            Log.d(LOG_TAG, LOG_PREFIX + "sent Rfid event");
        }
        // webView.postMessage("networkconnection", type);
    }

    private class AsyncTSLinit extends AsyncTask<String[], Void, Void> {
        @Override
        protected Void doInBackground(String[]... params) {

            //TSL
            // Ensure the shared instance of AsciiCommander exists
            AsciiCommander.createSharedInstance(context);

            AsciiCommander commander = getCommander();

            // Ensure that all existing responders are removed
            commander.clearResponders();

            // Add the LoggerResponder - this simply echoes all lines received from the reader to the log
            // and passes the line onto the next responder
            // This is added first so that no other responder can consume received lines before they are logged.
            //commander.addResponder(new LoggerResponder());

            // Add a synchronous responder to handle synchronous commands
            commander.addSynchronousResponder();

            // Create the single shared instance for this ApplicationContext
            ReaderManager.create(context);

            //Create a (custom) model and configure its commander and handler
            mModel = new InventoryModel();
            mModel.setCommander(getCommander());
            mModel.setCallback(TslRfidPlugin.this);
            //mModel.setEnabled(false);
            
            // Remember if the pause/resume was caused by ReaderManager - this will be cleared when ReaderManager.onResume() is called
            boolean readerManagerDidCauseOnPause = ReaderManager.sharedInstance().didCauseOnPause();

            // The ReaderManager needs to know about Activity lifecycle changes
            ReaderManager.sharedInstance().onResume();

            return null;
        }
    }

    @Override
    public void handleTagdata(String tagData) {
        if (TslRfidPlugin.this.webView != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "sending update handleTagdata:  " + tagData);
            sendRfidEvent(getJson("tagData", "" + tagData), true);
        }
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onDestroy() {

    }

    public void connect(String deviceAddress) {

            if(deviceAddress == null || deviceAddress.isEmpty()){
                sendRfidEvent(getJson("connection_status", "empty device address"), true);
                return;
            }

            // Update the ReaderList which will add any unknown reader, firing events appropriately
            ReaderManager.sharedInstance().updateList();

            ObservableReaderList readerList = ReaderManager.sharedInstance().getReaderList();
            if( readerList.list().size() >= 1)
            {
                Log.d(LOG_TAG, LOG_PREFIX + "ObservableReaderList size is: " + readerList.list().size());
                
                for (Reader reader : readerList.list())
                {
                    Log.d(LOG_TAG, LOG_PREFIX + "Reader display name:"+reader.getDisplayName());
                    Log.d(LOG_TAG, LOG_PREFIX + "Reader serial name:"+reader.getSerialNumber());
                    Log.d(LOG_TAG, LOG_PREFIX + "Reader MAC Address:"+reader.getDisplayInfoLine().trim());
                    Log.d(LOG_TAG, LOG_PREFIX + "device Address:"+deviceAddress);
                    //"1166-003793"
                    if (reader.getDisplayInfoLine()!=null && reader.getDisplayInfoLine().contains(deviceAddress))
                    {
                        mReader = reader;
                        Log.d(LOG_TAG, LOG_PREFIX + "found TSL reader in the list");
                        break;
                    }
                }
            }else{
                Log.d(LOG_TAG, LOG_PREFIX + "ObservableReaderList size is zero");
                sendRfidEvent(getJson("connection_status", "no nearby device found"), true);
                return;
            }

            // Register to receive notifications from the AsciiCommander
            LocalBroadcastManager.getInstance(cordova.getActivity()).registerReceiver(mCommanderMessageReceiver, new IntentFilter(AsciiCommander.STATE_CHANGED_NOTIFICATION));

            // // Remember if the pause/resume was caused by ReaderManager - this will be cleared when ReaderManager.onResume() is called
            // boolean readerManagerDidCauseOnPause = ReaderManager.sharedInstance().didCauseOnPause();
            // Log.d(LOG_TAG, LOG_PREFIX + "break point 8");

            // // The ReaderManager needs to know about Activity lifecycle changes
            // ReaderManager.sharedInstance().onResume();
            // Log.d(LOG_TAG, LOG_PREFIX + "break point 9");

            // Locate a Reader to use when necessary
            AutoSelectReader(true);

    }

    // Handle the messages broadcast from the AsciiCommander
    private BroadcastReceiver mCommanderMessageReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        
        Log.d("Ballu", "AsciiCommander state changed - isConnected: " + getCommander().isConnected()); 
    
        switch(getCommander().getConnectionState())
        {
            case CONNECTED:
                if (TslRfidPlugin.this.mConnectCallback != null) {
                    Log.d(LOG_TAG, LOG_PREFIX + "mConnectCallback is not null");
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Connected");
                    result.setKeepCallback(true);
                    TslRfidPlugin.this.mConnectCallback.sendPluginResult(result);
                    Log.d(LOG_TAG, LOG_PREFIX + "sent connection state event: Connected");
                }
                mModel.updateConfiguration();
            break;
            case CONNECTING:
                if (TslRfidPlugin.this.mConnectCallback != null) {
                    Log.d(LOG_TAG, LOG_PREFIX + "mConnectCallback is not null");
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Connecting");
                    result.setKeepCallback(true);
                    TslRfidPlugin.this.mConnectCallback.sendPluginResult(result);
                    Log.d(LOG_TAG, LOG_PREFIX + "sent connection state event: Connecting");
                }
            break;
            default:
                if (TslRfidPlugin.this.mConnectCallback != null) {
                    Log.d(LOG_TAG, LOG_PREFIX + "mConnectCallback is not null");
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Disconnected");
                    result.setKeepCallback(true);
                    TslRfidPlugin.this.mConnectCallback.sendPluginResult(result);
                    Log.d(LOG_TAG, LOG_PREFIX + "sent connection state event: Disconnected");
                }
        }
    // if( getCommander().isConnected() )
    // {
    // // Update for any change in power limits
    // setPowerBarLimits();
    // // This may have changed the current power level setting if the new range is smaller than the old range
    // // so update the model's inventory command for the new power value
    // mModel.getCommand().setOutputPower(mPowerLevel);
    
    // mModel.resetDevice();
    // mModel.updateConfiguration();
    // }
   
    // UpdateUI();
    }
   };

   public JSONObject getReaderInfo() throws JSONException {
    JSONObject readerInfo = new JSONObject();

        if(mReader!=null){
            DeviceProperties deviceProps = mReader.getDeviceProperties();
            VersionInformationCommand verionInfoCmd = deviceProps.getInformationCommand();

            readerInfo.put("MaximumCarrierPower", deviceProps.getMaximumCarrierPower());
            readerInfo.put("MinimumCarrierPower", deviceProps.getMinimumCarrierPower());
            readerInfo.put("AntennaSerialNumber", verionInfoCmd.getAntennaSerialNumber());
            readerInfo.put("AsciiProtocol", verionInfoCmd.getAsciiProtocol());
            readerInfo.put("BluetoothAddress", verionInfoCmd.getBluetoothAddress());
            readerInfo.put("BootloaderVersion", verionInfoCmd.getBootloaderVersion());
            readerInfo.put("FirmwareVersion", verionInfoCmd.getFirmwareVersion());
            readerInfo.put("Manufacturer", verionInfoCmd.getManufacturer());
            readerInfo.put("BluetoothVersion", verionInfoCmd.getBluetoothVersion());
            readerInfo.put("RadioFirmwareVersion", verionInfoCmd.getRadioFirmwareVersion());
            readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
            readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
            readerInfo.put("RadioSerialNumber", verionInfoCmd.getRadioSerialNumber());
            readerInfo.put("SerialNumber", verionInfoCmd.getSerialNumber());

            BatteryStatusCommand bCommand = BatteryStatusCommand.synchronousCommand();
            getCommander().executeCommand(bCommand);
            readerInfo.put("BatteryLevel", bCommand.getBatteryLevel());
        }
        return readerInfo;
    }

    private void getReaderState(CallbackContext callbackContext) {
        switch(getCommander().getConnectionState())
        {
            case CONNECTED:
                callbackContext.success("Connected");
                //sendRfidEvent(getJson("connection_status", "connected to reader:"+getCommander().getConnectedDeviceName()), true);
            break;
            case CONNECTING:
                callbackContext.success("Connecting");
                //sendRfidEvent(getJson("connection_status", "connecting..."), true);
            break;
            default:
                callbackContext.success("Disonnected");
                //sendRfidEvent(getJson("connection_status", "disconnected"), true);
        }
       }


}

