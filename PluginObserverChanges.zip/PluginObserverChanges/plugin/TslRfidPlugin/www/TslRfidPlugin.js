module.exports = {

        initRfidReader: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'initRfidReader', []);
        },

        readerEvents: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'startReaderEvents', []);
        },

        unSubscribeReaderEvents: function (successCallback, errorCallback) {
            cordova.exec(successCallback, errorCallback, 'TslRfidPlugin', 'unSubscribeReaderEvents', []);
        },

        connect: function (readerAddress, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'connect', [readerAddress]);
        },

        unSubscribeConnect: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'unSubscribeConnect', []);
        },

        disconnect: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'disconnect', []);
        },

        enableTagScan: function (value, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'enableTagScan', [value]);
        },

        enableBarcodeScan: function (value, success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'enableBarcodeScan', [value]);
        },

        scanTags: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'scanTags', []);
        },

        getConnectionStatus: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'getConnectionStatus', []);
        },

        getReaderProperties: function (success, error) {
            cordova.exec(success, error, 'TslRfidPlugin', 'getReaderProperties', []);
        }
};

// var tslRfidScanner = new TslRfidScanner();

// channel.createSticky('onCordovaConnectionReady');
// channel.waitForInitialization('onCordovaConnectionReady');

// module.exports = tslRfidScanner;
