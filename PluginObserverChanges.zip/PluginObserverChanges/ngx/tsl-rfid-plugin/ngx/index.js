import { __extends } from "tslib";
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var TslRfidPlugin = /** @class */ (function (_super) {
    __extends(TslRfidPlugin, _super);
    function TslRfidPlugin() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TslRfidPlugin.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true, "clearFunction": "unSubscribeConnect" }, arguments); };
    TslRfidPlugin.prototype.unSubscribeConnect = function () { return cordova(this, "unSubscribeConnect", {}, arguments); };
    TslRfidPlugin.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    TslRfidPlugin.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true, "clearFunction": "unSubscribeReaderEvents" }, arguments); };
    TslRfidPlugin.prototype.unSubscribeReaderEvents = function () { return cordova(this, "unSubscribeReaderEvents", {}, arguments); };
    TslRfidPlugin.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    TslRfidPlugin.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    TslRfidPlugin.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    TslRfidPlugin.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    TslRfidPlugin.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", {}, arguments); };
    TslRfidPlugin.prototype.initRfidReader = function () { return cordova(this, "initRfidReader", {}, arguments); };
    TslRfidPlugin.pluginName = "TslRfidPlugin";
    TslRfidPlugin.plugin = "com.techm.tslrfidplugin";
    TslRfidPlugin.pluginRef = "cordova.plugins.TslRfidPlugin";
    TslRfidPlugin.repo = "";
    TslRfidPlugin.platforms = ["Android"];
    TslRfidPlugin.decorators = [
        { type: Injectable }
    ];
    return TslRfidPlugin;
}(IonicNativePlugin));
export { TslRfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3RzbC1yZmlkLXBsdWdpbi9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDOztJQWtCQyxpQ0FBaUI7Ozs7SUFNbEQsK0JBQU8sYUFBQyxhQUFxQjtJQUs3QiwwQ0FBa0I7SUFLbEIsa0NBQVU7SUFRVixvQ0FBWTtJQUtaLCtDQUF1QjtJQUt2QixxQ0FBYSxhQUFDLEtBQWM7SUFLNUIseUNBQWlCLGFBQUMsS0FBYztJQUtoQyxnQ0FBUTtJQUtSLDJDQUFtQjtJQUtuQiwyQ0FBbUI7SUFLbkIsc0NBQWM7Ozs7Ozs7Z0JBNURmLFVBQVU7O3dCQW5CWDtFQW9CbUMsaUJBQWlCO1NBQXZDLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQbHVnaW4sIENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuLyoqXG4gKiBAbmFtZSBUc2wgUmZpZCBQbHVnaW5cbiAqIEBkZXNjcmlwdGlvblxuICogVGhpcyBwbHVnaW4gY29ubmVjdHMgdG8gUkZJRCByZWFkZXJcbiAqIHNjYW5zIHRhZ3MgYW5kIGJhcmNvZGVcbiAqL1xuXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ1RzbFJmaWRQbHVnaW4nLFxuICBwbHVnaW46ICdjb20udGVjaG0udHNscmZpZHBsdWdpbicsXG4gIHBsdWdpblJlZjogJ2NvcmRvdmEucGx1Z2lucy5Uc2xSZmlkUGx1Z2luJyxcbiAgcmVwbzogJycsXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJ11cbn0pXG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBUc2xSZmlkUGx1Z2luIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlLFxuICAgIGNsZWFyRnVuY3Rpb246ICd1blN1YnNjcmliZUNvbm5lY3QnXG4gIH0pXG4gIGNvbm5lY3QocmVhZGVyQWRkcmVzczogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICB1blN1YnNjcmliZUNvbm5lY3QoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBkaXNjb25uZWN0KCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlLFxuICAgIGNsZWFyRnVuY3Rpb246ICd1blN1YnNjcmliZVJlYWRlckV2ZW50cydcbiAgfSlcbiAgcmVhZGVyRXZlbnRzKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgdW5TdWJzY3JpYmVSZWFkZXJFdmVudHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBlbmFibGVUYWdTY2FuKHZhbHVlOiBib29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBlbmFibGVCYXJjb2RlU2Nhbih2YWx1ZTogYm9vbGVhbik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgc2NhblRhZ3MoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBnZXRDb25uZWN0aW9uU3RhdHVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0UmVhZGVyUHJvcGVydGllcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGluaXRSZmlkUmVhZGVyKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG59XG4iXX0=