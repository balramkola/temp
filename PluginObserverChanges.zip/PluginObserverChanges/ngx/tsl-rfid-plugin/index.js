var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var TslRfidPluginOriginal = /** @class */ (function (_super) {
    __extends(TslRfidPluginOriginal, _super);
    function TslRfidPluginOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TslRfidPluginOriginal.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true, "clearFunction": "unSubscribeConnect" }, arguments); };
    TslRfidPluginOriginal.prototype.unSubscribeConnect = function () { return cordova(this, "unSubscribeConnect", {}, arguments); };
    TslRfidPluginOriginal.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    TslRfidPluginOriginal.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true, "clearFunction": "unSubscribeReaderEvents" }, arguments); };
    TslRfidPluginOriginal.prototype.unSubscribeReaderEvents = function () { return cordova(this, "unSubscribeReaderEvents", {}, arguments); };
    TslRfidPluginOriginal.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    TslRfidPluginOriginal.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    TslRfidPluginOriginal.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    TslRfidPluginOriginal.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    TslRfidPluginOriginal.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", {}, arguments); };
    TslRfidPluginOriginal.prototype.initRfidReader = function () { return cordova(this, "initRfidReader", {}, arguments); };
    TslRfidPluginOriginal.pluginName = "TslRfidPlugin";
    TslRfidPluginOriginal.plugin = "com.techm.tslrfidplugin";
    TslRfidPluginOriginal.pluginRef = "cordova.plugins.TslRfidPlugin";
    TslRfidPluginOriginal.repo = "";
    TslRfidPluginOriginal.platforms = ["Android"];
    return TslRfidPluginOriginal;
}(IonicNativePlugin));
var TslRfidPlugin = new TslRfidPluginOriginal();
export { TslRfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3RzbC1yZmlkLXBsdWdpbi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQ0EsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDOztJQWtCQyxpQ0FBaUI7Ozs7SUFNbEQsK0JBQU8sYUFBQyxhQUFxQjtJQUs3QiwwQ0FBa0I7SUFLbEIsa0NBQVU7SUFRVixvQ0FBWTtJQUtaLCtDQUF1QjtJQUt2QixxQ0FBYSxhQUFDLEtBQWM7SUFLNUIseUNBQWlCLGFBQUMsS0FBYztJQUtoQyxnQ0FBUTtJQUtSLDJDQUFtQjtJQUtuQiwyQ0FBbUI7SUFLbkIsc0NBQWM7Ozs7Ozt3QkEvRWhCO0VBb0JtQyxpQkFBaUI7U0FBdkMsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBsdWdpbiwgQ29yZG92YSwgSW9uaWNOYXRpdmVQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuXG4vKipcbiAqIEBuYW1lIFRzbCBSZmlkIFBsdWdpblxuICogQGRlc2NyaXB0aW9uXG4gKiBUaGlzIHBsdWdpbiBjb25uZWN0cyB0byBSRklEIHJlYWRlclxuICogc2NhbnMgdGFncyBhbmQgYmFyY29kZVxuICovXG5cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnVHNsUmZpZFBsdWdpbicsXG4gIHBsdWdpbjogJ2NvbS50ZWNobS50c2xyZmlkcGx1Z2luJyxcbiAgcGx1Z2luUmVmOiAnY29yZG92YS5wbHVnaW5zLlRzbFJmaWRQbHVnaW4nLFxuICByZXBvOiAnJyxcbiAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnXVxufSlcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFRzbFJmaWRQbHVnaW4gZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG5cbiAgQENvcmRvdmEoe1xuICAgIG9ic2VydmFibGU6IHRydWUsXG4gICAgY2xlYXJGdW5jdGlvbjogJ3VuU3Vic2NyaWJlQ29ubmVjdCdcbiAgfSlcbiAgY29ubmVjdChyZWFkZXJBZGRyZXNzOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIHVuU3Vic2NyaWJlQ29ubmVjdCgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGRpc2Nvbm5lY3QoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoe1xuICAgIG9ic2VydmFibGU6IHRydWUsXG4gICAgY2xlYXJGdW5jdGlvbjogJ3VuU3Vic2NyaWJlUmVhZGVyRXZlbnRzJ1xuICB9KVxuICByZWFkZXJFdmVudHMoKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICB1blN1YnNjcmliZVJlYWRlckV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGVuYWJsZVRhZ1NjYW4odmFsdWU6IGJvb2xlYW4pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGVuYWJsZUJhcmNvZGVTY2FuKHZhbHVlOiBib29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBzY2FuVGFncygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXG4gIH1cblxuICBAQ29yZG92YSgpXG4gIGdldENvbm5lY3Rpb25TdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbiAgQENvcmRvdmEoKVxuICBnZXRSZWFkZXJQcm9wZXJ0aWVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcbiAgfVxuXG4gIEBDb3Jkb3ZhKClcbiAgaW5pdFJmaWRSZWFkZXIoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xuICB9XG5cbn1cbiJdfQ==