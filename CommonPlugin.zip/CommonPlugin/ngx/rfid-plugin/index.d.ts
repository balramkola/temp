import { IonicNativePlugin } from '@ionic-native/core';
import { Observable } from 'rxjs';
/**
 * @name RfidPlugin
 * @description
 * This plugin connects to RFID reader
 * scans tags and barcode
 */
export declare class RfidPluginOriginal extends IonicNativePlugin {
    connect(readerAddress: string): Observable<any>;
    stopConnEvents(): Promise<any>;
    disconnect(): Promise<any>;
    readerEvents(): Observable<any>;
    stopReaderEvents(): Promise<any>;
    enableTagScan(value: boolean): Promise<any>;
    enableBarcodeScan(value: boolean): Promise<any>;
    scanTags(): Promise<any>;
    getConnectionStatus(): Promise<any>;
    getReaderProperties(): Observable<any>;
    initRfidReader(libName: string): Observable<any>;
}

export declare const RfidPlugin: RfidPluginOriginal;