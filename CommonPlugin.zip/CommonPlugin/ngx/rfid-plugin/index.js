var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var RfidPluginOriginal = /** @class */ (function (_super) {
    __extends(RfidPluginOriginal, _super);
    function RfidPluginOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RfidPluginOriginal.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true }, arguments); };
    RfidPluginOriginal.prototype.stopConnEvents = function () { return cordova(this, "stopConnEvents", {}, arguments); };
    RfidPluginOriginal.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    RfidPluginOriginal.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true }, arguments); };
    RfidPluginOriginal.prototype.stopReaderEvents = function () { return cordova(this, "stopReaderEvents", {}, arguments); };
    RfidPluginOriginal.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    RfidPluginOriginal.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    RfidPluginOriginal.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    RfidPluginOriginal.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    RfidPluginOriginal.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", { "observable": true }, arguments); };
    RfidPluginOriginal.prototype.initRfidReader = function (libName) { return cordova(this, "initRfidReader", {}, arguments); };
    RfidPluginOriginal.pluginName = "RfidPlugin";
    RfidPluginOriginal.plugin = "com.techm.rfidplugin";
    RfidPluginOriginal.pluginRef = "cordova.plugins.RfidPlugin";
    RfidPluginOriginal.repo = "";
    RfidPluginOriginal.platforms = ["Android"];
    return RfidPluginOriginal;
}(IonicNativePlugin));
var RfidPlugin = new RfidPluginOriginal();
export { RfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3JmaWQtcGx1Z2luL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDQSxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBa0JGLDhCQUFpQjs7OztJQUsvQyw0QkFBTyxhQUFDLGFBQXFCO0lBSzdCLG1DQUFjO0lBS2QsK0JBQVU7SUFPVixpQ0FBWTtJQUtaLHFDQUFnQjtJQUtoQixrQ0FBYSxhQUFDLEtBQWM7SUFLNUIsc0NBQWlCLGFBQUMsS0FBYztJQUtoQyw2QkFBUTtJQUtSLHdDQUFtQjtJQU9uQix3Q0FBbUI7SUFLbkIsbUNBQWMsYUFBQyxPQUFlOzs7Ozs7cUJBL0VoQztFQW9CZ0MsaUJBQWlCO1NBQXBDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFBsdWdpbiwgQ29yZG92YSwgSW9uaWNOYXRpdmVQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG4vKipcclxuICogQG5hbWUgUmZpZFBsdWdpblxyXG4gKiBAZGVzY3JpcHRpb25cclxuICogVGhpcyBwbHVnaW4gY29ubmVjdHMgdG8gUkZJRCByZWFkZXJcclxuICogc2NhbnMgdGFncyBhbmQgYmFyY29kZVxyXG4gKi9cclxuXHJcbiBAUGx1Z2luKHtcclxuICBwbHVnaW5OYW1lOiAnUmZpZFBsdWdpbicsXHJcbiAgcGx1Z2luOiAnY29tLnRlY2htLnJmaWRwbHVnaW4nLFxyXG4gIHBsdWdpblJlZjogJ2NvcmRvdmEucGx1Z2lucy5SZmlkUGx1Z2luJyxcclxuICByZXBvOiAnJyxcclxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCddXHJcbn0pXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBSZmlkUGx1Z2luIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICBjb25uZWN0KHJlYWRlckFkZHJlc3M6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIHN0b3BDb25uRXZlbnRzKCk6IFByb21pc2U8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIGRpc2Nvbm5lY3QoKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICByZWFkZXJFdmVudHMoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSgpXHJcbiAgc3RvcFJlYWRlckV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBlbmFibGVUYWdTY2FuKHZhbHVlOiBib29sZWFuKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSgpXHJcbiAgZW5hYmxlQmFyY29kZVNjYW4odmFsdWU6IGJvb2xlYW4pOiBQcm9taXNlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBzY2FuVGFncygpOiBQcm9taXNlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBnZXRDb25uZWN0aW9uU3RhdHVzKCk6IFByb21pc2U8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoe1xyXG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxyXG4gIH0pXHJcbiAgZ2V0UmVhZGVyUHJvcGVydGllcygpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBpbml0UmZpZFJlYWRlcihsaWJOYW1lOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG59XHJcbiJdfQ==