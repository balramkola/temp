import { __extends } from "tslib";
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var RfidPlugin = /** @class */ (function (_super) {
    __extends(RfidPlugin, _super);
    function RfidPlugin() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RfidPlugin.prototype.connect = function (readerAddress) { return cordova(this, "connect", { "observable": true }, arguments); };
    RfidPlugin.prototype.stopConnEvents = function () { return cordova(this, "stopConnEvents", {}, arguments); };
    RfidPlugin.prototype.disconnect = function () { return cordova(this, "disconnect", {}, arguments); };
    RfidPlugin.prototype.readerEvents = function () { return cordova(this, "readerEvents", { "observable": true }, arguments); };
    RfidPlugin.prototype.stopReaderEvents = function () { return cordova(this, "stopReaderEvents", {}, arguments); };
    RfidPlugin.prototype.enableTagScan = function (value) { return cordova(this, "enableTagScan", {}, arguments); };
    RfidPlugin.prototype.enableBarcodeScan = function (value) { return cordova(this, "enableBarcodeScan", {}, arguments); };
    RfidPlugin.prototype.scanTags = function () { return cordova(this, "scanTags", {}, arguments); };
    RfidPlugin.prototype.getConnectionStatus = function () { return cordova(this, "getConnectionStatus", {}, arguments); };
    RfidPlugin.prototype.getReaderProperties = function () { return cordova(this, "getReaderProperties", { "observable": true }, arguments); };
    RfidPlugin.prototype.initRfidReader = function (libName) { return cordova(this, "initRfidReader", {}, arguments); };
    RfidPlugin.pluginName = "RfidPlugin";
    RfidPlugin.plugin = "com.techm.rfidplugin";
    RfidPlugin.pluginRef = "cordova.plugins.RfidPlugin";
    RfidPlugin.repo = "";
    RfidPlugin.platforms = ["Android"];
    RfidPlugin.decorators = [
        { type: Injectable }
    ];
    return RfidPlugin;
}(IonicNativePlugin));
export { RfidPlugin };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3JmaWQtcGx1Z2luL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBa0JGLDhCQUFpQjs7OztJQUsvQyw0QkFBTyxhQUFDLGFBQXFCO0lBSzdCLG1DQUFjO0lBS2QsK0JBQVU7SUFPVixpQ0FBWTtJQUtaLHFDQUFnQjtJQUtoQixrQ0FBYSxhQUFDLEtBQWM7SUFLNUIsc0NBQWlCLGFBQUMsS0FBYztJQUtoQyw2QkFBUTtJQUtSLHdDQUFtQjtJQU9uQix3Q0FBbUI7SUFLbkIsbUNBQWMsYUFBQyxPQUFlOzs7Ozs7O2dCQTVEL0IsVUFBVTs7cUJBbkJYO0VBb0JnQyxpQkFBaUI7U0FBcEMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUGx1Z2luLCBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcbi8qKlxyXG4gKiBAbmFtZSBSZmlkUGx1Z2luXHJcbiAqIEBkZXNjcmlwdGlvblxyXG4gKiBUaGlzIHBsdWdpbiBjb25uZWN0cyB0byBSRklEIHJlYWRlclxyXG4gKiBzY2FucyB0YWdzIGFuZCBiYXJjb2RlXHJcbiAqL1xyXG5cclxuIEBQbHVnaW4oe1xyXG4gIHBsdWdpbk5hbWU6ICdSZmlkUGx1Z2luJyxcclxuICBwbHVnaW46ICdjb20udGVjaG0ucmZpZHBsdWdpbicsXHJcbiAgcGx1Z2luUmVmOiAnY29yZG92YS5wbHVnaW5zLlJmaWRQbHVnaW4nLFxyXG4gIHJlcG86ICcnLFxyXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJ11cclxufSlcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFJmaWRQbHVnaW4gZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XHJcblxyXG4gIEBDb3Jkb3ZhKHtcclxuICAgIG9ic2VydmFibGU6IHRydWVcclxuICB9KVxyXG4gIGNvbm5lY3QocmVhZGVyQWRkcmVzczogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSgpXHJcbiAgc3RvcENvbm5FdmVudHMoKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSgpXHJcbiAgZGlzY29ubmVjdCgpOiBQcm9taXNlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKHtcclxuICAgIG9ic2VydmFibGU6IHRydWVcclxuICB9KVxyXG4gIHJlYWRlckV2ZW50cygpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBzdG9wUmVhZGVyRXZlbnRzKCk6IFByb21pc2U8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIGVuYWJsZVRhZ1NjYW4odmFsdWU6IGJvb2xlYW4pOiBQcm9taXNlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKClcclxuICBlbmFibGVCYXJjb2RlU2Nhbih2YWx1ZTogYm9vbGVhbik6IFByb21pc2U8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIHNjYW5UYWdzKCk6IFByb21pc2U8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIGdldENvbm5lY3Rpb25TdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICBnZXRSZWFkZXJQcm9wZXJ0aWVzKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoKVxyXG4gIGluaXRSZmlkUmVhZGVyKGxpYk5hbWU6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbn1cclxuIl19