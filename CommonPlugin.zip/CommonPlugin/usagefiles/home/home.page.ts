import { Component } from '@angular/core';
import { BDevice } from '../models/bluetooth-device';
//import data from '../data/data.json';
import { NavigationExtras, Router } from '@angular/router';
import { BluetoothSerial } from '@ionic-native/bluetooth-serial/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  PREFIX_LOG: string = "IONIC UI: ";
  items = [];
  bDevices: BDevice[] = [];
  eventsTextView: string = "";

  constructor(private router: Router,private bluetoothSerial: BluetoothSerial) {
    // data.forEach((bdevice) => {
    //   let device: BDevice = {
    //     address: bdevice.eventInfo.address,
    //     paired: bdevice.eventInfo.paired,
    //     name: bdevice.eventInfo.name,
    //   };

    //   this.bDevices.push(device);
    // });
  }

  public viewBDeviceInfo(bDevice: BDevice): void {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        special: JSON.stringify(bDevice),
      },
    };
    this.router.navigate(['/b-device-info'], navigationExtras);
  }

  pairedDevices: BDevice[] = [];
  unPairedDevices: BDevice[] = [];

  public scan(): void {
    this.pairedDevices = [];
    this.unPairedDevices = [];
    this.getPairedDevices();
    this.eventsTextView = "Scanning....";
    this.bluetoothSerial.discoverUnpaired().then((devices: {}[]) => {
      this.eventsTextView = "Scanning Completed";
      console.log('UnPaired Devices Found:', devices);
      devices.forEach((device) => {
        if (!device['name']) device['name'] = 'Unknown';
        let bdevice: BDevice = {
              address: device['id'],
              paired: false,
              name: device['name'],
            };
        this.unPairedDevices.push(bdevice);
      });
    });
  }

  private getPairedDevices(): void {
    this.bluetoothSerial.list().then((pairedDevices) => {
      console.log('Paired Devices', pairedDevices);
      pairedDevices.forEach((device) => {
        if (!device['name']) device['name'] = 'Unknown';
        let bdevice: BDevice = {
              address: device['address'],
              paired: true,
              name: device['name'],
            };
        this.pairedDevices.push(bdevice);
      });
    });
  }

}
