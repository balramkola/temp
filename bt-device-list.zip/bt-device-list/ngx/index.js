import { __extends } from "tslib";
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var BTDeviceList = /** @class */ (function (_super) {
    __extends(BTDeviceList, _super);
    function BTDeviceList() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BTDeviceList.prototype.startScan = function () { return cordova(this, "startScan", { "observable": true }, arguments); };
    BTDeviceList.prototype.stopScan = function () { return cordova(this, "stopScan", { "observable": true }, arguments); };
    BTDeviceList.prototype.getBondedDevices = function () { return cordova(this, "getBondedDevices", { "observable": true }, arguments); };
    BTDeviceList.pluginName = "BTDeviceList";
    BTDeviceList.plugin = "cordova-plugin-BTDeviceList";
    BTDeviceList.pluginRef = "BTDeviceList";
    BTDeviceList.repo = "";
    BTDeviceList.platforms = ["Android", "iOS"];
    BTDeviceList.decorators = [
        { type: Injectable }
    ];
    return BTDeviceList;
}(IonicNativePlugin));
export { BTDeviceList };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2J0LWRldmljZS1saXN0L25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBVUEsZ0NBQWlCOzs7O0lBS2pELGdDQUFTO0lBT1QsK0JBQVE7SUFPUix1Q0FBZ0I7Ozs7Ozs7Z0JBcEJqQixVQUFVOzt1QkFYWDtFQVlrQyxpQkFBaUI7U0FBdEMsWUFBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUGx1Z2luLCBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcbkBQbHVnaW4oe1xyXG4gIHBsdWdpbk5hbWU6ICdCVERldmljZUxpc3QnLFxyXG4gIHBsdWdpbjogJ2NvcmRvdmEtcGx1Z2luLUJURGV2aWNlTGlzdCcsXHJcbiAgcGx1Z2luUmVmOiAnQlREZXZpY2VMaXN0JyxcclxuICByZXBvOiAnJyxcclxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsJ2lPUyddXHJcbn0pXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEJURGV2aWNlTGlzdCBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcclxuXHJcbiAgQENvcmRvdmEoe1xyXG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxyXG4gIH0pXHJcbiAgc3RhcnRTY2FuKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcbiAgQENvcmRvdmEoe1xyXG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxyXG4gIH0pXHJcbiAgc3RvcFNjYW4oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICBnZXRCb25kZWREZXZpY2VzKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm47IC8vIFdlIGFkZCByZXR1cm47IGhlcmUgdG8gYXZvaWQgYW55IElERSAvIENvbXBpbGVyIGVycm9yc1xyXG4gIH1cclxuXHJcblxyXG59XHJcblxyXG4iXX0=