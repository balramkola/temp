var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var BTDeviceListOriginal = /** @class */ (function (_super) {
    __extends(BTDeviceListOriginal, _super);
    function BTDeviceListOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BTDeviceListOriginal.prototype.startScan = function () { return cordova(this, "startScan", { "observable": true }, arguments); };
    BTDeviceListOriginal.prototype.stopScan = function () { return cordova(this, "stopScan", { "observable": true }, arguments); };
    BTDeviceListOriginal.prototype.getBondedDevices = function () { return cordova(this, "getBondedDevices", { "observable": true }, arguments); };
    BTDeviceListOriginal.pluginName = "BTDeviceList";
    BTDeviceListOriginal.plugin = "cordova-plugin-BTDeviceList";
    BTDeviceListOriginal.pluginRef = "BTDeviceList";
    BTDeviceListOriginal.repo = "";
    BTDeviceListOriginal.platforms = ["Android", "iOS"];
    return BTDeviceListOriginal;
}(IonicNativePlugin));
var BTDeviceList = new BTDeviceListOriginal();
export { BTDeviceList };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2J0LWRldmljZS1saXN0L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDQSxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBVUEsZ0NBQWlCOzs7O0lBS2pELGdDQUFTO0lBT1QsK0JBQVE7SUFPUix1Q0FBZ0I7Ozs7Ozt1QkEvQmxCO0VBWWtDLGlCQUFpQjtTQUF0QyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBQbHVnaW4sIENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuQFBsdWdpbih7XHJcbiAgcGx1Z2luTmFtZTogJ0JURGV2aWNlTGlzdCcsXHJcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tQlREZXZpY2VMaXN0JyxcclxuICBwbHVnaW5SZWY6ICdCVERldmljZUxpc3QnLFxyXG4gIHJlcG86ICcnLFxyXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJywnaU9TJ11cclxufSlcclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQlREZXZpY2VMaXN0IGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICBzdGFydFNjYW4oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuICBAQ29yZG92YSh7XHJcbiAgICBvYnNlcnZhYmxlOiB0cnVlXHJcbiAgfSlcclxuICBzdG9wU2NhbigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuOyAvLyBXZSBhZGQgcmV0dXJuOyBoZXJlIHRvIGF2b2lkIGFueSBJREUgLyBDb21waWxlciBlcnJvcnNcclxuICB9XHJcblxyXG4gIEBDb3Jkb3ZhKHtcclxuICAgIG9ic2VydmFibGU6IHRydWVcclxuICB9KVxyXG4gIGdldEJvbmRlZERldmljZXMoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybjsgLy8gV2UgYWRkIHJldHVybjsgaGVyZSB0byBhdm9pZCBhbnkgSURFIC8gQ29tcGlsZXIgZXJyb3JzXHJcbiAgfVxyXG5cclxuXHJcbn1cclxuXHJcbiJdfQ==