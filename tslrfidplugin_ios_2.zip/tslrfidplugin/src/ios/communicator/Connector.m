#import "Connector.h"

#import <TSLAsciiCommands/TSLAsciiCommands.h>
#import <TSLAsciiCommands/TSLBinaryEncoding.h>
#import <ExternalAccessory/ExternalAccessory.h>
#import <ExternalAccessory/EAAccessoryManager.h>

@implementation Connector
@synthesize connectorDelegate;
NSString *const CONNECTOR_TAG_PREFIX=@"PLUGIN:Connector: ";
EAAccessoryManager *mAccessoryManager;

-(void) connect:(NSString *)readerAddress{
    NSLog(@"%@Reader address = %@",CONNECTOR_TAG_PREFIX, readerAddress);
    mAccessoryManager = [EAAccessoryManager sharedAccessoryManager];
    if(mAccessoryManager == nil){
        NSLog(@"%@Reader address = %@",CONNECTOR_TAG_PREFIX, readerAddress);
        [self onError:@"Bluetooth API is not available"];
        return;
    }
    NSArray *accessories = [mAccessoryManager connectedAccessories];
    if (accessories.count == 0) {
        NSLog(@"%@Accessories list is empty",CONNECTOR_TAG_PREFIX);
        [self onError:@"Device list is empty, Reader not found"];
        return ;
    }
    
    bool accessoryFound = false;
    for (int i = 0 ; i < [accessories count] ; i++)
    {
        accessory = [accessories objectAtIndex:i];
        if([accessory.serialNumber isEqualToString:readerAddress] ){
            NSLog(@"%@Reader found in Accessory list",CONNECTOR_TAG_PREFIX);
            accessoryFound=true;
            break;
        }
    }
    if(!accessoryFound){
        NSLog(@"%@Reader not found in accessory list",CONNECTOR_TAG_PREFIX);
        [self onError:@"Reader not found in accessory list"];
        return;
    }
    
    NSLog(@"%@Reader details: %@",CONNECTOR_TAG_PREFIX,accessory);
    //    NSLog(@"%@accessory serial number: %@",CONNECTOR_TAG_PREFIX, accessory.serialNumber);
    //    NSLog(@"%@accessory protocol: %@",CONNECTOR_TAG_PREFIX, accessory.protocolStrings);
    
    //    if (accessory.protocolStrings.count == 0){
    //        NSLog(@"%@reader protocol count is zero",CONNECTOR_TAG_PREFIX);
    //        [self onError:@"reader protocol count is zero"];
    //        return;
    //    }
    
    //    NSLog(@"%@Readers list size = %lu",CONNECTOR_TAG_PREFIX,(unsigned long)accessories.count);
    //    NSLog(@"%@Readers list = %@",CONNECTOR_TAG_PREFIX, accessories);
    
    if(_commander == nil ){
        NSLog(@"%@Commander is not initialized, initializing it",CONNECTOR_TAG_PREFIX);
        _commander = [[TSLAsciiCommander alloc] init];
    }
    [_commander clearResponders];
    [_commander addSynchronousResponder];
    
    [self regStateChanges];
    
    self.readerAddress = readerAddress;
    
    NSLog(@"%@Calling connect method in Commander",CONNECTOR_TAG_PREFIX);
    if([_commander connect:accessory]){
        NSLog(@"%@Commander's connect method executed properly",CONNECTOR_TAG_PREFIX);
    }else{
        NSLog(@"%@Commander's connect method executed improperly",CONNECTOR_TAG_PREFIX);
        [self onError:@"Unable to execute connect command"];
    }
    
}

-(void)regStateChanges{
    NSLog(@"%@Registering for connection state changes",CONNECTOR_TAG_PREFIX);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onReaderStatechange) name:TSLCommanderStateChangedNotification object:_commander];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onEAAccessoryConnected:) name:EAAccessoryDidConnectNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onEAAccessoryDisConnected:) name:EAAccessoryDidDisconnectNotification object:nil];
    [[EAAccessoryManager sharedAccessoryManager] registerForLocalNotifications];
}

-(void)unRegStateChanges{
    NSLog(@"%@UnRegistering connection state changes",CONNECTOR_TAG_PREFIX);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:TSLCommanderStateChangedNotification object:_commander];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EAAccessoryDidConnectNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EAAccessoryDidDisconnectNotification object:nil];
    [[EAAccessoryManager sharedAccessoryManager] unregisterForLocalNotifications];
}

-(void)onEAAccessoryConnected:(EAAccessory *)accessory{
    NSLog(@"%@onEAAccessoryConnected called up: %@",CONNECTOR_TAG_PREFIX,@"accessory.serialNumber");
}

-(void)onEAAccessoryDisConnected:(EAAccessory *)accessory{
    NSLog(@"%@onEAAccessoryDisConnected called up: %@",CONNECTOR_TAG_PREFIX,@"accessory.serialNumber");
}

-(void)onReaderStatechange
{
    NSLog(@"%@onReaderStatechange function called",CONNECTOR_TAG_PREFIX);
    
    if(_commander != nil ){
        
        if(_commander.isConnected )
        {
            NSLog(@"%@Reader connected",CONNECTOR_TAG_PREFIX);
            [self onConnected];
        }
        else
        {
            NSLog(@"%@Reader disconnected",CONNECTOR_TAG_PREFIX);
            [self onDisconnected];
        }
        return;
    }
    
    NSLog(@"%@Commander is not initialized",CONNECTOR_TAG_PREFIX);
    [self onError:@"Commander is not initialized"];
}

-(void) disconnect{
    NSLog(@"%@calling disconnect method from connector",CONNECTOR_TAG_PREFIX);
    [self unRegStateChanges];
    if(_commander != nil ){
        if(_commander.isConnected)
        {
            NSLog(@"%@Calling commander disconnect method",CONNECTOR_TAG_PREFIX);
            [_commander disconnect];
            [self onDisconnected];
        }
        else
        {
            NSLog(@"%@Reader disconnected",CONNECTOR_TAG_PREFIX);
            [self onDisconnected];
        }
    }
}

-(NSString *) getConnectionStatus{
    
    if(_commander == nil ){
        return @"Disonnected";
    }
    if(_commander.isConnected )
    {
        return @"Connected";
    }
    return @"Disonnected";
}

-(NSString *)getReaderProps{
    NSLog(@"%@starting executing getReaderProperties",CONNECTOR_TAG_PREFIX);
    versionCommand = [TSLVersionInformationCommand synchronousCommand];
    TSLBatteryStatusCommand *batteryCommand = [TSLBatteryStatusCommand synchronousCommand];
    if(_commander != nil){
        if(_commander.isConnected){
            [_commander executeCommand:versionCommand];
            [_commander executeCommand:batteryCommand];
            int minPower = [TSLInventoryCommand minimumOutputPower];
            int maxPower = [TSLInventoryCommand maximumOutputPower];
            
            NSMutableDictionary *readerProps = [[NSMutableDictionary alloc] init];
            
            [readerProps setObject:(versionCommand.antennaSerialNumber == nil ) ? @"N/A" : versionCommand.antennaSerialNumber forKey:@"AntennaSerialNumber"];
            
            [readerProps setObject:(versionCommand.bluetoothAddress == nil ) ? @"N/A" : versionCommand.bluetoothAddress forKey:@"BluetoothAddress"];
            [readerProps setObject:(versionCommand.asciiProtocol == nil ) ? @"N/A" : versionCommand.asciiProtocol forKey:@"AsciiProtocol"];
            [readerProps setObject:(versionCommand.bootloaderVersion == nil ) ? @"N/A" : versionCommand.bootloaderVersion forKey:@"BootloaderVersion"];
            [readerProps setObject:(versionCommand.firmwareVersion == nil ) ? @"N/A" : versionCommand.firmwareVersion forKey:@"FirmwareVersion"];
            [readerProps setObject:(versionCommand.manufacturer == nil ) ? @"N/A" : versionCommand.manufacturer forKey:@"Manufacturer"];
            [readerProps setObject:(versionCommand.radioFirmwareVersion == nil ) ? @"N/A" : versionCommand.radioFirmwareVersion forKey:@"RadioFirmwareVersion"];
            [readerProps setObject:(versionCommand.radioBootloaderVersion == nil ) ? @"N/A" : versionCommand.radioBootloaderVersion forKey:@"RadioBootloaderVersion"];
            [readerProps setObject:(versionCommand.radioSerialNumber == nil ) ? @"N/A" : versionCommand.radioSerialNumber forKey:@"RadioSerialNumber"];
            [readerProps setObject:(versionCommand.serialNumber == nil ) ? @"N/A" : versionCommand.serialNumber forKey:@"SerialNumber"];
            
            [readerProps setObject:[NSNumber numberWithInt:batteryCommand.batteryLevel] forKey:@"BatteryLevel"];
            [readerProps setObject:[NSNumber numberWithInt:maxPower] forKey:@"MaximumCarrierPower"];
            [readerProps setObject:[NSNumber numberWithInt:minPower] forKey:@"MinimumCarrierPower"];
            
            NSError *error;
            NSData *readPropsJsonData = [NSJSONSerialization dataWithJSONObject:readerProps
                                                                        options:NSJSONWritingPrettyPrinted
                                                                          error:&error];
            
            if (!readPropsJsonData) {
                NSLog(@"Got an error while converting reader props map to json string: %@", error);
                [self setErrMsg:[error localizedDescription]];
                return nil;
            } else {
                NSString *readPropsJsonStr = [[NSString alloc] initWithData:readPropsJsonData encoding:NSUTF8StringEncoding];
                return readPropsJsonStr;
            }
            
        }
        else {
            NSLog(@"%@Reader disconnected",CONNECTOR_TAG_PREFIX);
            [self setErrMsg:@"Reader disconnected"];
            return nil;
        }
    }
    else{
        NSLog(@"%@Commander is not ready ",CONNECTOR_TAG_PREFIX);
        [self setErrMsg:@"Commander is not ready"];
        return nil;
    }
}

-(void) onConnected{
    NSLog(@"%@onConnected called up",CONNECTOR_TAG_PREFIX);
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onConnected];
    }
}

-(void) onDisconnected{
    NSLog(@"%@onDisconnected called up",CONNECTOR_TAG_PREFIX);
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onDisconnected];
    }
}

-(void) onError:(NSString *)errMsg{
    NSLog(@"%@onError called up",CONNECTOR_TAG_PREFIX);
    if([self connectorDelegate] != nil){
        [[self connectorDelegate] onError:errMsg];
    }
}

-(TSLAsciiCommander* )getCommander{
    return _commander;
}

-(void) setErrMsg:(NSString *)errorMsg{
    errMsg = errorMsg;
}

-(NSString *)getErrMsg{
    return errMsg;
}

-(BOOL) checkConnStatus:(NSString *)readerAddress{
    if(_commander != nil && _commander.isConnected && [[_commander connectedAccessory].serialNumber isEqualToString:readerAddress]){
        return TRUE;
    }
    return FALSE;
}

@end
