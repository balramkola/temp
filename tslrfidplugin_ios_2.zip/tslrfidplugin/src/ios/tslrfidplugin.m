/********* tslrfidplugin.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>

#import <UIKit/UIKit.h>

#import "TslHandler.h"

@interface tslrfidplugin : CDVPlugin<TslHandlerDelegate> {
    NSString* mReaderEventsCallbackId;
    NSString* mConnectCallbackId;
    NSString* mLibCallbackId;
    NSString* mReaderPropsCallbackId;
    TslHandler *mTslHandler;
}
- (void)initRfidReader:(CDVInvokedUrlCommand*)command;
- (void)startReaderEvents:(CDVInvokedUrlCommand*)command;
- (void)stopReaderEvents:(CDVInvokedUrlCommand*)command;
- (void)connect:(CDVInvokedUrlCommand*)command;
- (void)stopConnEvents:(CDVInvokedUrlCommand*)command;
- (void)disconnect:(CDVInvokedUrlCommand*)command;
- (void)enableTagScan:(CDVInvokedUrlCommand*)command;
- (void)enableBarcodeScan:(CDVInvokedUrlCommand*)command;
- (void)scanTags:(CDVInvokedUrlCommand*)command;
- (void)getConnectionStatus:(CDVInvokedUrlCommand*)command;
- (void)getReaderProperties:(CDVInvokedUrlCommand*)command;
- (void)sendLibEventToUI:(NSString*)event :(bool)keepCallback;
- (void)sendEventToIonic:(NSDictionary*)jsonInfo :(bool)keepCallback;
- (void)sendConnStateEventToUI:(NSString*)connState :(bool)keepCallback;
- (void)libErr;
@end

@implementation tslrfidplugin

NSString *const TAG_PREFIX=@"PLUGIN:tslrfidplugin: ";

-(void)viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)initRfidReader:(CDVInvokedUrlCommand*)command
{
    NSString *libstring = [command.arguments objectAtIndex:0];
    NSLog(@"%@Initializing %@ library",TAG_PREFIX,libstring);
    mTslHandler = [[TslHandler alloc]init];
    [mTslHandler setTslHandlerDelegate:self];
    mLibCallbackId = command.callbackId;
    [self sendLibEventToUI:@"LIB_INITIALIZED" :TRUE];
}

- (void)enableTagScan:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@enableTagScan method called",TAG_PREFIX);
    
    BOOL enableBoolValue=NO;
    @try
    {
        NSString *boolValue = [command.arguments objectAtIndex:0];
        NSLog(@"%@enable tag scan = %@",TAG_PREFIX,boolValue);
        if (boolValue)
            enableBoolValue = YES;
        else
            enableBoolValue = NO;
    }
    @catch(NSException *exception) {
        NSLog(@"%@Caught an exception:%@",TAG_PREFIX,exception.userInfo);
        NSDictionary *dict= @{
            @"eventType": @"ERROR",
            @"eventValue": [NSString stringWithFormat:@"%@%@", @"Invalid argument: " , exception.userInfo],
        };
        [self sendEventToIonic:dict :TRUE];
        return;
    }
    
    if(mTslHandler != nil){
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"SUCCESS"];
        [pluginResult setKeepCallbackAsBool:FALSE];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
        
        [mTslHandler  setEnableRfid:enableBoolValue];
    }else{
        NSLog(@"%@TSL library is not initialized",TAG_PREFIX);
        [self libErr];
    }
}

- (void)enableBarcodeScan:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@enableBarcodeScan called",TAG_PREFIX);
    
    BOOL enableBoolValue=NO;
    @try
    {
        NSString *boolStr = [command.arguments objectAtIndex:0];
        if ([boolStr isEqualToString:@"YES"])
            enableBoolValue = YES;
        else if ([boolStr isEqualToString:@"NO"])
            enableBoolValue = NO;
    }
    @catch(NSException *exception) {
        NSLog(@"Caught an exception:%@",exception.userInfo);
        [self libErr];
    }
    
    if(mTslHandler != nil){
        [mTslHandler  setEnableBarcode:enableBoolValue];
    }else{
        NSLog(@"%@TSL library is not initialized",TAG_PREFIX);
        [self libErr];
    }
}

- (void)scanTags:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@scanTags action called up",TAG_PREFIX);
    //TODO run below code in thread block
    [self.commandDelegate runInBackground:^{
        if(self->mTslHandler != nil){
            NSLog(@"%@initiating scan command for tag detection",TAG_PREFIX);
            [self->mTslHandler scanTags];
        }else{
            NSLog(@"%@TSL library is not initialized",TAG_PREFIX);
            [self libErr];
        }
    }];
}

- (void)getConnectionStatus:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@getConnectionStatus action called",TAG_PREFIX);
    if(mTslHandler == nil){
        NSLog(@"%@reader library is not initialized",TAG_PREFIX);
        [self libErr];
        return;
    }
    NSString *connStatus=[mTslHandler getConnectionStatus];
    NSLog(@"%@connection status: %@",TAG_PREFIX,connStatus);
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:connStatus];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)getReaderProperties:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@getReaderProperties action called up",TAG_PREFIX);
    [self.commandDelegate runInBackground:^{
        if(self->mTslHandler == nil){
            NSLog(@"%@Reader library is not initialized",TAG_PREFIX);
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"Reader is not ready"];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
            return;
        }
        
        NSLog(@"%@calling getReaderproperties method",TAG_PREFIX);
        NSDictionary *readerPropsDict=[self->mTslHandler getReaderProps];
        NSLog(@"%@ReaderPros: %@",TAG_PREFIX,readerPropsDict);
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:readerPropsDict];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }];
}

- (void)startReaderEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@startReaderEvents",TAG_PREFIX);
    mReaderEventsCallbackId = command.callbackId;
    [self sendEventToIonic:nil :true];
}

- (void)stopReaderEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@stopReaderEvents",TAG_PREFIX);
    mReaderEventsCallbackId = nil;
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)connect:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@connect action called up",TAG_PREFIX);
    if(mTslHandler == nil){
        NSLog(@"%@TSL library is not initialized",TAG_PREFIX);
        [self libErr];
        return;
    }
    [self.commandDelegate runInBackground:^{
        NSString *readerAddress = [command.arguments objectAtIndex:0];
        if([self validation:readerAddress]){
            NSLog(@"%@Valid Reader Addrress",TAG_PREFIX);
            self->mConnectCallbackId = command.callbackId;
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"CONNECTING"];
            [pluginResult setKeepCallbackAsBool:TRUE];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:self->mConnectCallbackId];
            [self->mTslHandler  connect:readerAddress];
        }
        else{
            NSLog(@"%@Invalid Reader Addrress",TAG_PREFIX);
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"Invalid Reader Address"];
            [pluginResult setKeepCallbackAsBool:false];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:self->mConnectCallbackId];
        }
    }];
}

-(bool)validation:(NSString *)readerAddress{
    if(readerAddress == nil)
        return false;
    else
        return true;
}

- (void)stopConnEvents:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@stopConnEvents",TAG_PREFIX);
}

- (void)disconnect:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@disconnect action called up",TAG_PREFIX);
    if(mTslHandler == nil){
        NSLog(@"%@reader library is not insalized ",TAG_PREFIX);
        [self libErr];
    }
    else{
        NSLog(@"%@calling disconnect method",TAG_PREFIX);
        [mTslHandler disconnect];
    }
}

- (void)onConnected {
    NSLog(@"%@onConnected called up",TAG_PREFIX);
    [self sendConnStateEventToUI:@"CONNECTED" :TRUE];
}

- (void)onDisconnected {
    NSLog(@"%@onDisconnected called up",TAG_PREFIX);
    [self sendConnStateEventToUI:@"DISCONNECTED" :TRUE];
}

- (void)onError:(NSDictionary *)errMsg {
    NSLog(@"%@onError called up",TAG_PREFIX);
    [self sendEventToIonic:errMsg :TRUE];
}

- (void)onBarcodeDetected:(NSDictionary *)barcodeInfo {
    NSLog(@"%@onBarcodeDetected called up",TAG_PREFIX);
    [self sendEventToIonic:barcodeInfo :TRUE];
}

- (void)onTagDetected:(NSDictionary *)tagInfo {
    NSLog(@"%@onTagDetected called up",TAG_PREFIX);
    [self sendEventToIonic:tagInfo :TRUE];
}

- (void)sendConnStateEventToUI:(NSString*)connState :(bool)keepCallback{
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:connState];
    [pluginResult setKeepCallbackAsBool:keepCallback];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:mConnectCallbackId];
}

- (void)sendLibEventToUI:(NSString*)event :(bool)keepCallback{
    NSLog(@"%@sendLibEventToUI called",TAG_PREFIX);
    if(self.webView != nil && mLibCallbackId != nil && event != nil){
        NSLog(@"sending library state event to ionic UI:%@",event);
        CDVPluginResult* pluginResult = nil;
        if(nil == event){
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
        }else{
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:event];
        }
        [pluginResult setKeepCallbackAsBool:keepCallback];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:mLibCallbackId];
    }else{
        NSLog(@"unable to send lib event info to ionic UI");
    }
}

- (void)sendEventToIonic:(NSDictionary*)jsonInfo :(bool)keepCallback{
    NSLog(@"sendEventToIonic() called");
    if(self.webView != nil && mReaderEventsCallbackId != nil){
        NSLog(@"sending event to ionic UI:%@",jsonInfo);
        CDVPluginResult* pluginResult = nil;
        if(nil == jsonInfo){
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
        }else{
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:jsonInfo];
        }
        [pluginResult setKeepCallbackAsBool:keepCallback];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:mReaderEventsCallbackId];
    }else{
        NSLog(@"unable to send event info to ionic UI");
    }
}

- (void)libErr{
    NSDictionary *dict= @{
        @"eventType": @"ERROR",
        @"eventValue": [NSString stringWithFormat:@"%@", @"TSL Library is not initialized"],
    };
    [self sendEventToIonic:dict :TRUE];
}

@end
