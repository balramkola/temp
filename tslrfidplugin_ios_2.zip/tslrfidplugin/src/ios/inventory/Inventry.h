
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <TSLAsciiCommands/TSLAsciiCommands.h>
#import "Connector.h"

@protocol InventoryDelegate
@required
- (void)onTagDetected:(NSDictionary *)tagInfo;
- (void)onBarcodeDetected:(NSDictionary *)barcodeInfo;
- (void)onErrorEvent:(NSDictionary *)errMsg;
@end
//TSLInventoryCommandTransponderReceivedDelegate
@interface Inventry :NSObject<TSLBarcodeCommandBarcodeReceivedDelegate> {
    
    TSLInventoryCommand *_inventoryResponder;
    TSLBarcodeCommand *_barcodeResponder;
    TSLAsciiCommander *_commander;
    TSLInventoryCommand *mReaderConfigCmd;
    bool mRfidEnabled;
    bool mBarcodeEnabled;
    bool mIsReaderBusy;
    bool mAnyTagSeen;
}

@property (nonatomic, assign) id  <InventoryDelegate> inventoryDelegate;

-(void) initInventory;
-(void) setReaderConfig;
-(TSLInventoryCommand* ) getReaderConfigCmd;
-(void) setRfidEnabled:(bool)value;
-(void) setBarcodeEnabled:(bool)value;
-(void) resetDevice;
-(void) scanTags;
-(BOOL) testForAntenna;
-(void) setCommander:(TSLAsciiCommander* )commander;
-(void) sendTagEvent:(NSString *)eventValue;
-(void) sendBarcodeEvent:(NSString *)eventValue;
-(void) sendErrorEvent:(NSString *)eventValue;
-(NSDictionary *) getFormattedEvent:(NSString *)eventType :(NSString *)eventValue;

@end
