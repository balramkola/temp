#import <Foundation/Foundation.h>
#import "Connector.h"
#import "Inventry.h"

#import <TSLAsciiCommands/TSLAsciiCommands.h>

@protocol TslHandlerDelegate
@required
- (void)onDisconnected;
- (void)onConnected;
- (void)onError:(NSDictionary *)errMsg;

- (void)onTagDetected:(NSDictionary *)tagInfo;
- (void)onBarcodeDetected:(NSDictionary *)barcodeInfo;
@end

@interface TslHandler :NSObject<ConnectorDelegate,InventoryDelegate>{
    Connector *connector;
    Inventry *inventry;
    TSLAsciiCommander *_commander;
}

@property (nonatomic, assign) id  <TslHandlerDelegate> tslHandlerDelegate;

-(void) connect:(NSString *)readerAddress;
-(void) disconnect;
-(NSString *) getConnectionStatus;
-(NSDictionary *)getReaderProps;
-(void)scanTags;
-(void)setEnableBarcode:(BOOL)value;
-(void)setEnableRfid:(BOOL)value;
-(NSDictionary *) getJsonMsg:(NSString*)eventType :(NSString*)eventValue;

@end

