module.exports = {

    initRfidReader: function (libName, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'tslrfidplugin', 'initRfidReader', [libName]);
    },

    readerEvents: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'tslrfidplugin', 'startReaderEvents', []);
    },

    stopReaderEvents: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'tsltslrfidplugin', 'stopReaderEvents', []);
    },

    connect: function (readerAddress, success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'connect', [readerAddress]);
    },

    stopConnEvents: function (success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'stopConnEvents', []);
    },

    disconnect: function (success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'disconnect', []);
    },

    enableTagScan: function (value, success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'enableTagScan', [value]);
    },

    enableBarcodeScan: function (value, success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'enableBarcodeScan', [value]);
    },

    scanTags: function (success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'scanTags', []);
    },

    getConnectionStatus: function (success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'getConnectionStatus', []);
    },

    getReaderProperties: function (success, error) {
        cordova.exec(success, error, 'tslrfidplugin', 'getReaderProperties', []);
    }
};
