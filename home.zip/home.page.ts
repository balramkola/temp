import { Component } from '@angular/core';
import { BDevice } from '../models/bluetooth-device';
//import data from '../data/data.json';
import { NavigationExtras, Router } from '@angular/router';
import { BluetoothSerial } from '@ionic-native/bluetooth-serial/ngx';
import { BTDeviceList } from '@ionic-native/bt-device-list/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  PREFIX_LOG: string = "IONIC UI: ";
  items = [];
  bDevices: BDevice[] = [];
  eventsTextView: string = "";

  constructor(private router: Router,private bluetoothSerial: BluetoothSerial,private btDeviceList: BTDeviceList) {
    // data.forEach((bdevice) => {
    //   let device: BDevice = {
    //     address: bdevice.eventInfo.address,
    //     paired: bdevice.eventInfo.paired,
    //     name: bdevice.eventInfo.name,
    //   };

    //   this.bDevices.push(device);
    // });
  }

  public viewBDeviceInfo(bDevice: BDevice): void {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        special: JSON.stringify(bDevice),
      },
    };
    this.router.navigate(['/b-device-info'], navigationExtras);
  }

  pairedDevices: BDevice[] = [];
  unPairedDevices: BDevice[] = [];

  public stopScan(): void {
    this.btDeviceList.stopScan().subscribe((info) => {
      console.log(this.PREFIX_LOG + 'received event from bt devices stop scan plugin code');
    });
  }

  public startScan(): void {
    this.pairedDevices = [];
    this.unPairedDevices = [];
    //this.getPairedDevices();
    this.eventsTextView = "Scanning....";
    this.btDeviceList.startScan().subscribe((info) => {
      console.log(this.PREFIX_LOG + 'received event from bt devices start scan plugin code');
      if (info == null) {
        return;
      }
      
      console.log(this.PREFIX_LOG + "event: "+info);
      console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);

      if (info.eventType == "DeviceFound") {
        let bdevice: BDevice = {
          address: info.eventValue.address,
          paired: info.eventValue.paired,
          name: info.eventValue.name,
        };
      this.unPairedDevices.push(bdevice);
      } else
        if (info.eventType == "BondedDevice") {
          let jsonObj: any = JSON.parse(info.eventValue);
          console.log(this.PREFIX_LOG + "info.eventValue.address: "+jsonObj.address);
          console.log(this.PREFIX_LOG + "info.eventValue.paired: "+jsonObj.paired);
          console.log(this.PREFIX_LOG + "info.eventValue.name: "+jsonObj.name);
          
          let bdevice: BDevice = {
            address: jsonObj.address,
            paired: jsonObj.paired,
            name: jsonObj.name,
          };
      this.pairedDevices.push(bdevice);
        } else
          {
            this.eventsTextView = info.eventValue;
          }
    });
  }

}
