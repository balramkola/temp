package com.techm.rfidplugin.factory;

import org.json.JSONObject;

public interface IRFIDHandlerCallback {
    void onEvent(JSONObject eventJson);

    void onLibEvent(String libEvent);

    void onConnEvent(String connStatInfo);

    void onInventoryEvent(JSONObject eventJson);

    void onReaderProps(JSONObject propsJson);
}
