package com.techm.rfidplugin.tsl.comm;

public class ConfigParams {
    boolean enableRfid=true;
    boolean enableBarcode=true;
    String deviceAddress="";
}
