package com.techm.rfidplugin.zebra.comm;

import android.content.Context;
import android.util.Log;

import com.zebra.rfid.api3.ENUM_TRANSPORT;
import com.zebra.rfid.api3.InvalidUsageException;
import com.zebra.rfid.api3.OperationFailureException;
import com.zebra.rfid.api3.RFIDReader;
import com.zebra.rfid.api3.ReaderDevice;
import com.zebra.rfid.api3.Readers;
import com.zebra.rfid.api3.RfidEventsListener;
import com.zebra.rfid.api3.RfidReadEvents;
import com.zebra.rfid.api3.RfidStatusEvents;
import com.zebra.rfid.api3.STATUS_EVENT_TYPE;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import static com.techm.rfidplugin.zebra.comm.ConnectionState.CONNECTED;
import static com.techm.rfidplugin.zebra.comm.ConnectionState.DISCONNECTED;

public class Connector implements Readers.RFIDReaderEventHandler, RfidEventsListener {
    private static final String LOG_TAG = Connector.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private final Context mContext;

    private RFIDReader mReader = null;
    private String mReaderAddr = null;
    private boolean isRegStateEvent = false;
    private IConnStateChange mConnStateCallback = null;

    private Readers mReaders;
    private ArrayList<ReaderDevice> mAvailableRFIDReaderList;

    public Connector(Context context) {
        mContext = context;
        updateReadersList();
    }

    private void updateReadersList() {
        if (null == mContext) {
            Log.d(LOG_TAG, LOG_PREFIX + "context is null");
            setError("Unable to fetch Reader list");
        }
        try {
            if (mReaders == null)
                mReaders = new Readers(mContext, ENUM_TRANSPORT.BLUETOOTH);
            if (null != mReaders) {
                mAvailableRFIDReaderList = mReaders.GetAvailableRFIDReaderList();
                if (null != mAvailableRFIDReaderList)
                    Log.d(LOG_TAG, LOG_PREFIX + "Available Zebra Reader list size:" + mAvailableRFIDReaderList.size());
                else
                    setError("Unable to fetch Reader list");
            }
        } catch (InvalidUsageException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "Unable to fetch Reader list:" + e.getInfo());
            setError("Unable to fetch Reader list");
        }
    }

    public void connect(String deviceAddress) {

        if (deviceAddress == null || deviceAddress.isEmpty()) {
            setError("empty device address");
            Log.d(LOG_TAG, LOG_PREFIX + "empty device address");
            return;
        }

        RFIDReader reader = searchReaderInAvailableList(deviceAddress);
        if (reader != null && mReader != null && mReader.getHostName().equals(reader.getHostName())) {
            if (mReader.isConnected()) {
                Log.d(LOG_TAG, LOG_PREFIX + "Connected to Reader:" + mReader.getHostName());
                setConnState(CONNECTED);
                regStateChanges();
                return;
            }
        }
        connectReader(reader);
    }

    private void connectReader(RFIDReader reader) {
        Log.d(LOG_TAG, LOG_PREFIX + "connectToReader called up");
        mReader = reader;
        if (null == mReader) {
            Log.d(LOG_TAG, LOG_PREFIX + "device not found");
            setError("Device not found");
            return;
        }
        if (mReader != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader hostname:" + mReader.getHostName());
            try {
                if (!mReader.isConnected()) {
                    // Establish connection to the RFID Reader
                    mReader.connect();
                    setConnState(CONNECTED);
                    regStateChanges();
                    Log.d(LOG_TAG, LOG_PREFIX + "connected to Reader: " + mReader.getHostName());
                }
            } catch (InvalidUsageException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "OperationFailureException " + e.getVendorMessage());
                setError("Connection failed: " + e.getVendorMessage());
            } catch (OperationFailureException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "OperationFailureException " + e.getVendorMessage());
                String des = e.getResults().toString();
                setError("Connection failed: " + e.getVendorMessage() + " " + des);
            }
        }
    }

    private synchronized RFIDReader searchReaderInAvailableList(String deviceAddress) {
        Log.d(LOG_TAG, LOG_PREFIX + "searchReaderInAvailableList");
        try {
            if (mReaders != null && mReaders.GetAvailableRFIDReaderList() != null) {
                mAvailableRFIDReaderList = mReaders.GetAvailableRFIDReaderList();
                if (mAvailableRFIDReaderList.size() != 0) {
                    // search reader specified by name
                    for (ReaderDevice device : mAvailableRFIDReaderList) {
                        Log.d(LOG_TAG, LOG_PREFIX + "ReaderDevice getName:" + device.getName());
                        Log.d(LOG_TAG, LOG_PREFIX + "ReaderDevice getAddress:" + device.getAddress());
                        if (device.getAddress().equals(deviceAddress)) {
                            mReaderAddr = deviceAddress;
                            return device.getRFIDReader();
                        }
                    }
                }
            }
        } catch (InvalidUsageException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "error in searchReaderInAvailableList: " + e.getVendorMessage());
        }
        return null;
    }

    public void disconnect() {
        unRegStateChanges();
        disconnectReader();
        mReader = null;
        mReaderAddr = "";
    }

    public void dispose() {
        try {
            if (mReaders != null) {
                mReader = null;
                mReaders.Dispose();
                mReaders = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void disconnectReader() {
        Log.d(LOG_TAG, LOG_PREFIX + "disconnecting Reader");
        if (mReader != null && mReader.isConnected()) {
            try {
                //mReader.Events.removeEventsListener(eventHandler);//TODO move this to Inventory model
                mReader.disconnect();
                Log.d(LOG_TAG, LOG_PREFIX + "Reader disconnected:" + mReader.getHostName());
            } catch (InvalidUsageException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "Exception while disconnecting:" + e.getInfo());
                setError("Unable to disconnect");
            } catch (OperationFailureException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "Exception while disconnecting:" + e.getVendorMessage());
                setError("Unable to disconnect");
            }
        }
        setConnState(DISCONNECTED);
    }

    public void regStateChanges() {
        if (!isRegStateEvent && mReaders != null) {
            mReaders.attach(Connector.this);
            if (mReader == null || mReader.Events == null) {
                //TODO reader is not connected unable to add event listener
                Log.d(LOG_TAG, LOG_PREFIX + "reader is not connected unable to add disconnection event listener");
                setError("unable to add disconnection event listener");
                return;
            }
            try {
                Log.d(LOG_TAG, LOG_PREFIX + "registering for disconnection events");
                // receive events from reader
                mReader.Events.setReaderDisconnectEvent(true);
                mReader.Events.setBatteryEvent(true);
                mReader.Events.setPowerEvent(true);
                mReader.Events.addEventsListener(Connector.this);
            } catch (InvalidUsageException | OperationFailureException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "error while adding disconnection event listener:" + e.getMessage());
                setError(e.getMessage());
                return;
            }
            isRegStateEvent = true;
        }
    }

    public void unRegStateChanges() {
        if (isRegStateEvent && mReaders != null) {
            mReaders.deattach(Connector.this);
            try {
                if (mReader != null && mReader.Events != null) {
                    Log.d(LOG_TAG, LOG_PREFIX + "unregistering disconnection events");
                    mReader.Events.setReaderDisconnectEvent(false);
                    mReader.Events.setBatteryEvent(false);
                    mReader.Events.setPowerEvent(false);
                    mReader.Events.removeEventsListener(Connector.this);
                } else {
                    //TODO reader is not connected unable to delete event listener
                    return;
                }
            } catch (InvalidUsageException | OperationFailureException e) {
                Log.d(LOG_TAG, LOG_PREFIX + "error while deleting listener:" + e.getMessage());
                setError(e.getMessage());
                return;
            }
            isRegStateEvent = false;
        }
    }

    public JSONObject getReaderInfo() {
        JSONObject readerInfo = new JSONObject();

        if (mReader != null && mReader.isConnected()) {
            HashMap<String, String> deviceInfo = new HashMap<>();
            try {
                mReader.Config.getDeviceVersionInfo(deviceInfo);
                Log.d(LOG_TAG, LOG_PREFIX + "Reader details:" + deviceInfo.toString());
                return new JSONObject(deviceInfo);
            } catch (InvalidUsageException e) {
                String errMsg = "Unable to get Reader info:" + e.getVendorMessage();
                Log.d(LOG_TAG, LOG_PREFIX + errMsg);
                setError(errMsg);
            } catch (OperationFailureException e) {
                String errMsg = "Unable to get Reader info:" + e.getVendorMessage();
                Log.d(LOG_TAG, LOG_PREFIX + errMsg);
                setError(errMsg);
            }

            /*try {
                readerInfo.put("MaximumCarrierPower", deviceInfo.getMaximumCarrierPower());
                readerInfo.put("MinimumCarrierPower", deviceProps.getMinimumCarrierPower());
                readerInfo.put("AntennaSerialNumber", verionInfoCmd.getAntennaSerialNumber());
                readerInfo.put("AsciiProtocol", verionInfoCmd.getAsciiProtocol());
                readerInfo.put("BluetoothAddress", verionInfoCmd.getBluetoothAddress());
                readerInfo.put("BootloaderVersion", verionInfoCmd.getBootloaderVersion());
                readerInfo.put("FirmwareVersion", verionInfoCmd.getFirmwareVersion());
                readerInfo.put("Manufacturer", verionInfoCmd.getManufacturer());
                readerInfo.put("BluetoothVersion", verionInfoCmd.getBluetoothVersion());
                readerInfo.put("RadioFirmwareVersion", verionInfoCmd.getRadioFirmwareVersion());
                readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
                readerInfo.put("RadioBootloaderVersion", verionInfoCmd.getRadioBootloaderVersion());
                readerInfo.put("RadioSerialNumber", verionInfoCmd.getRadioSerialNumber());
                readerInfo.put("SerialNumber", verionInfoCmd.getSerialNumber());

                BatteryStatusCommand bCommand = BatteryStatusCommand.synchronousCommand();
                getCommander().executeCommand(bCommand);
                readerInfo.put("BatteryLevel", bCommand.getBatteryLevel());
            } catch (JSONException e) {
                return new JSONObject();
            }*/

        }
        return readerInfo;
    }

    public ConnectionState getReaderConnState() {
        if (mReader == null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader Connection Status:" + DISCONNECTED.name());
            return DISCONNECTED;
        }
        if (mReader.isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader Connection Status:" + CONNECTED.name());
            return CONNECTED;
        }
        Log.d(LOG_TAG, LOG_PREFIX + "Reader Connection Status:" + DISCONNECTED.name());
        return DISCONNECTED;
    }

    private void setConnState(ConnectionState state) {
        if (null != mConnStateCallback) {
            mConnStateCallback.onConnStateChange(state);
        }
    }

    private void setError(String errMsg) {
        if (null != mConnStateCallback) {
            mConnStateCallback.onError(errMsg);
        }
    }

    public void setConnStateCallback(IConnStateChange connStateCallback) {
        mConnStateCallback = connStateCallback;
    }

    // handler for receiving reader appearance events
    @Override
    public void RFIDReaderAppeared(ReaderDevice readerDevice) {
        Log.d(LOG_TAG, LOG_PREFIX + "RFIDReaderAppeared " + readerDevice.getName());
        if (mReaderAddr != null && !mReaderAddr.isEmpty()) {
            // set Reader to previously disconnected Reader, if the connection type is BT
            if (readerDevice.getAddress().equals(mReaderAddr)) {
                if (mReader != null && !mReader.isConnected()) {
                    connectReader(readerDevice.getRFIDReader());
                    return;
                }
                setConnState(CONNECTED);
            }
        }
    }

    @Override
    public void RFIDReaderDisappeared(ReaderDevice readerDevice) {
        Log.d(LOG_TAG, LOG_PREFIX + "RFIDReaderDisappeared " + readerDevice.getName());
        if (mReaderAddr != null && !mReaderAddr.isEmpty()) {
            if (readerDevice.getAddress().equals(mReaderAddr)) {
                Log.d(LOG_TAG, LOG_PREFIX + "Reader disconnected:" + readerDevice.getName());
                disconnectReader();
            }
        }
    }

    @Override
    public void eventReadNotify(RfidReadEvents rfidReadEvents) {

    }

    @Override
    public void eventStatusNotify(RfidStatusEvents rfidStatusEvents) {
        Log.d(LOG_TAG, LOG_PREFIX + "RfidStatusEvents: " + rfidStatusEvents.StatusEventData.getStatusEventType());
        if (rfidStatusEvents.StatusEventData.getStatusEventType() == STATUS_EVENT_TYPE.DISCONNECTION_EVENT) {
            Log.d(LOG_TAG, LOG_PREFIX + rfidStatusEvents.StatusEventData.DisconnectionEventData.getDisconnectionEvent().toString());
            disconnect();
        } else if (rfidStatusEvents.StatusEventData.getStatusEventType() == STATUS_EVENT_TYPE.BATTERY_EVENT) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader Battery level:" + rfidStatusEvents.StatusEventData.BatteryData.getLevel());
            //setError(""+rfidStatusEvents.StatusEventData.BatteryData.getLevel());
        }
    }

    public RFIDReader getReader() {
        return mReader;
    }

    public interface IConnStateChange {
        void onConnStateChange(ConnectionState connectionState);

        void onError(String errMsg);
    }
}
