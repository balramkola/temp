package com.techm.rfidplugin.zebra.comm;

public class ConfigParams {
    boolean enableRfid=true;
    boolean enableBarcode=true;
    String deviceAddress="";
}
