package com.techm.rfidplugin.zebra.comm;

public enum ConnectionState {
    UNDEFINED,
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    INTERRUPTED,
    LOST;

    private ConnectionState() {
    }
}
