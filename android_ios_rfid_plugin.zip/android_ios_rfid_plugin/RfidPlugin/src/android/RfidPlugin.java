package com.techm.rfidplugin;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.util.Log;

import com.techm.rfidplugin.factory.IRFIDHandler;
import com.techm.rfidplugin.factory.IRFIDHandlerCallback;
import com.techm.rfidplugin.factory.PluginFactory;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RfidPlugin extends CordovaPlugin {

    private static final String LOG_TAG = RfidPlugin.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private CallbackContext mReaderEventsCallbackCtx = null;
    private CallbackContext mConnectCallbackCtx = null;
    private CallbackContext mLibCallbackCtx = null;
    private IRFIDHandler mRfidHandler;
    private CallbackContext mReaderPropsCallbackContext = null;

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.mConnectCallbackCtx = null;
        this.mLibCallbackCtx = null;
        this.mReaderEventsCallbackCtx = null;
        this.mReaderPropsCallbackContext = null;
    }

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        boolean validAction = true;

        if (action.equals("initRfidReader")) {

            Log.d(LOG_TAG, LOG_PREFIX + "initializing RFID Reader");
            cordova.getThreadPool().execute(() -> {
                String libName = null;
                try {
                    Log.d(LOG_TAG, LOG_PREFIX + "plugin library name:" + args.getString(0));
                    libName = args.getString(0);
                } catch (JSONException e) {
                    Log.d(LOG_TAG, LOG_PREFIX + "Invalid Plugin library name" + e.getMessage());
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "NO_LIB");
                    result.setKeepCallback(false);
                    callbackContext.sendPluginResult(result);
                    return;
                }

                mRfidHandler = getReaderHandler(libName); //TODO use provider to get the ReaderHandler for different Reader models(Zebra,TSL,etc...)
                if (null == mRfidHandler) {
                    Log.d(LOG_TAG, LOG_PREFIX + "Plugin doesn't exist");
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "NO_LIB");
                    result.setKeepCallback(false);
                    callbackContext.sendPluginResult(result);
                    return;
                }
                this.mLibCallbackCtx = callbackContext;
                addEventListeners();
                mRfidHandler.initLib(cordova.getActivity());
            });

        } else if (action.equals("startReaderEvents")) {

            Log.d(LOG_TAG, LOG_PREFIX + "startReaderEvents called");
            this.mReaderEventsCallbackCtx = callbackContext;
            sendEventToIonic(null, true);

        } else if (action.equals("stopReaderEvents")) {

            Log.d(LOG_TAG, LOG_PREFIX + "stopReaderEvents action called");
            this.mReaderEventsCallbackCtx = null;
            callbackContext.success();

        } else if (action.equals("connect")) {

            Log.d(LOG_TAG, LOG_PREFIX + "connect action called");
            cordova.getThreadPool().execute(() -> {
                //TODO move below logic to Connector class
                if (BluetoothAdapter.getDefaultAdapter() == null) {
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Device does not support Bluetooth");
                    result.setKeepCallback(false);
                    callbackContext.sendPluginResult(result);
                }

                String macAddress = null;
                try {
                    Log.d(LOG_TAG, LOG_PREFIX + "device address:" + args.getString(0));
                    macAddress = args.getString(0);
                } catch (JSONException e) {
                    Log.d(LOG_TAG, LOG_PREFIX + "Invalid device address" + e.getMessage());
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Could not connect to " + macAddress + "Invalid device address");
                    result.setKeepCallback(false);
                    callbackContext.sendPluginResult(result);
                    return;
                }
                BluetoothDevice device = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(macAddress);

                if (device != null) {
                    mConnectCallbackCtx = callbackContext;
                    mRfidHandler.connect(macAddress);
                    PluginResult result = new PluginResult(PluginResult.Status.NO_RESULT);
                    result.setKeepCallback(true);
                    callbackContext.sendPluginResult(result);

                } else {
                    PluginResult result = new PluginResult(PluginResult.Status.OK, "Could not connect to " + macAddress);
                    result.setKeepCallback(false);
                    callbackContext.sendPluginResult(result);
                }
            });
        } else if (action.equals("stopConnEvents")) {

            Log.d(LOG_TAG, LOG_PREFIX + "stopConnEvents action called");
            mConnectCallbackCtx = null;
            PluginResult result = new PluginResult(PluginResult.Status.OK);
            result.setKeepCallback(false);
            callbackContext.sendPluginResult(result);

        } else if (action.equals("disconnect")) {
            cordova.getThreadPool().execute(() -> {
                if (mRfidHandler != null) {
                    mRfidHandler.disconnect();
                    Log.d(LOG_TAG, LOG_PREFIX + "disconnecting Reader");
                    //callbackContext.success();
                } else {
                    callbackContext.error("TSL library is not initialized");
                }
            });
        } else if (action.equals("getReaderProperties")) {
            mReaderPropsCallbackContext = callbackContext;
            cordova.getThreadPool().execute(() -> {
                if (mRfidHandler != null) {
                    mRfidHandler.getReaderProps();
                } else {
                    callbackContext.error("TSL library is not initialized");
                }
            });

        } else if (action.equals("getConnectionStatus")) {
            if (mRfidHandler != null) {
                callbackContext.success(mRfidHandler.getConnStatus());
            } else {
                callbackContext.error("TSL library is not initialized");
            }

        } else if (action.equals("enableTagScan")) {

            if (mRfidHandler != null) {
                //register for tag events
                try {
                    mRfidHandler.setEnableRfid(args.getBoolean(0));
                    Log.d(LOG_TAG, LOG_PREFIX + "registering for tag events");
                } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                    callbackContext.error(arrayIndexOutOfBoundsException.getMessage());
                } catch (ClassCastException classCastException) {
                    callbackContext.error(classCastException.getMessage());
                } catch (Exception exception) {
                    callbackContext.error(exception.getMessage());
                }
            } else {
                callbackContext.error("TSL library is not initialized");
            }

        } else if (action.equals("enableBarcodeScan")) {

            if (mRfidHandler != null) {
                //register for tag events
                try {
                    mRfidHandler.setEnableBarcode(args.getBoolean(0));
                    Log.d(LOG_TAG, LOG_PREFIX + "registering for barcode events");
                } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                    callbackContext.error(arrayIndexOutOfBoundsException.getMessage());
                } catch (ClassCastException classCastException) {
                    callbackContext.error(classCastException.getMessage());
                } catch (Exception exception) {
                    callbackContext.error(exception.getMessage());
                }
            } else {
                callbackContext.error("TSL library is not initialized");
            }

        } else if (action.equals("scanTags")) {

            cordova.getThreadPool().execute(() -> {
                if (mRfidHandler != null) {
                    Log.d(LOG_TAG, LOG_PREFIX + "executing scan command for tag detection");
                    mRfidHandler.scanTags();
                    //callbackContext.success();
                } else {
                    callbackContext.error("TSL library is not initialized");
                }
            });
        } else {
            validAction = false;
        }
        return validAction;
    }

    private void removeEventListners() {
        if (mRfidHandler != null) {
            mRfidHandler.setCallback(null);
        }
    }

    private void addEventListeners() {
        if (mRfidHandler != null) {
            mRfidHandler.setCallback(new IRFIDHandlerCallback() {
                @Override
                public void onEvent(JSONObject eventJson) {
                    sendEventToIonic(eventJson, true);
                }

                @Override
                public void onLibEvent(String libEvent) {
                    sendLibEventToUI(libEvent);
                }

                @Override
                public void onConnEvent(String connStatInfo) {
                    sendConnStateEventToUI(connStatInfo);
                }

                @Override
                public void onInventoryEvent(JSONObject eventJson) {
                    sendEventToIonic(eventJson, true);
                }

                @Override
                public void onReaderProps(JSONObject propsJson) {
                    sendReaderPropsToUi(propsJson);
                }
            });
        }
    }

    private void sendReaderPropsToUi(JSONObject propsJson) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendReaderPropsToUi called:" + propsJson.toString());
        if (RfidPlugin.this.webView != null && mReaderPropsCallbackContext != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "sending reader props event to IONIC UI:  " + propsJson);
            PluginResult result = new PluginResult(PluginResult.Status.OK, propsJson);
            result.setKeepCallback(false);
            mReaderPropsCallbackContext.sendPluginResult(result);
            mReaderPropsCallbackContext = null;
        } else {
            Log.d(LOG_TAG, LOG_PREFIX + "mReaderPropsCallbackContext is null");
        }
    }

    private void sendConnStateEventToUI(String connectionState) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendConnStateEventToUI called");
        if (RfidPlugin.this.webView != null && mConnectCallbackCtx != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "sending connection state event to IONIC UI:  " + connectionState);
            PluginResult result = new PluginResult(PluginResult.Status.OK, connectionState);
            result.setKeepCallback(true);
            mConnectCallbackCtx.sendPluginResult(result);
        }
    }

    private void sendLibEventToUI(String event) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendLibEventToUI called");
        if (RfidPlugin.this.webView != null && mConnectCallbackCtx != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "sending library state event to IONIC UI:  " + event);
            PluginResult result = new PluginResult(PluginResult.Status.OK, event);
            result.setKeepCallback(false);
            this.mLibCallbackCtx.sendPluginResult(result);
        }
    }

    private void sendEventToIonic(JSONObject info, boolean keepCallback) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendEventToIonic() called");
        if (RfidPlugin.this.webView != null && this.mReaderEventsCallbackCtx != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "sending event to IONIC UI:  " + info);
            PluginResult result;
            if (null == info) {
                result = new PluginResult(PluginResult.Status.OK);
            } else {
                result = new PluginResult(PluginResult.Status.OK, info);
            }
            result.setKeepCallback(keepCallback);
            this.mReaderEventsCallbackCtx.sendPluginResult(result);
        }
    }

    private IRFIDHandler getReaderHandler(String pluginName) {
        return PluginFactory.getInstance(pluginName);
    }

    @Override
    public void onPause(boolean multitasking) {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onPause() called");
        if (mRfidHandler != null) {
            mRfidHandler.onPause();
        }
    }

    /**
     * Called when the activity will start interacting with the user.
     *
     * @param multitasking Flag indicating if multitasking is turned on for app
     */
    @Override
    public void onResume(boolean multitasking) {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onResume() called");
        if (mRfidHandler != null) {
            mRfidHandler.onResume();
        }
    }

    /**
     * Called when the activity is becoming visible to the user.
     */
    @Override
    public void onStart() {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onStart() called");
    }

    /**
     * Called when the activity is no longer visible to the user.
     */
    @Override
    public void onStop() {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onStop() called");
    }

    /**
     * Called when the activity receives a new intent.
     */
    @Override
    public void onNewIntent(Intent intent) {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onNewIntent() called");
    }

    /**
     * The final call you receive before your activity is destroyed.
     */
    @Override
    public void onDestroy() {
        Log.d(LOG_TAG, LOG_PREFIX + "activity lifecycle onDestroy() called");
//        if (mTslHandler != null) {
//            mTslHandler.disconnect();
//            Log.d(LOG_TAG, LOG_PREFIX + "disconnecting Reader");
//        }
//        removeEventListners();
    }
}

