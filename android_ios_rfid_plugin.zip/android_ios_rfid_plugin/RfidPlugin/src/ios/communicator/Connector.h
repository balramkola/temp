#import <Foundation/Foundation.h>

#import <TSLAsciiCommands/TSLAsciiCommands.h>
#import <TSLAsciiCommands/TSLBinaryEncoding.h>
#import <ExternalAccessory/ExternalAccessory.h>
#import <ExternalAccessory/EAAccessoryManager.h>

@protocol ConnectorDelegate
@required
- (void)onDisconnected;
- (void)onConnected;
- (void)onError:(NSString *)errMsg;
@end

@interface Connector :NSObject{
    TSLAsciiCommander *_commander;
    EAAccessory *accessory;
    TSLVersionInformationCommand * versionCommand;
    NSString *errMsg;
}

@property (nonatomic, assign) id  <ConnectorDelegate> connectorDelegate;

@property (nonatomic,weak) NSString *readerAddress;

-(void) connect:(NSString *)readerAddress;
-(void) disconnect;
-(NSString *)getConnectionStatus;
-(void) onConnected;
-(void) onDisconnected;
-(void) onError:(NSString *)errMsg;
-(TSLAsciiCommander* )getCommander;
-(NSString *)getReaderProps;
-(NSString *)getErrMsg;
-(void) setErrMsg:(NSString *)errMsg;
-(BOOL) checkConnStatus:(NSString *)readerAddress;
-(void) onEAAccessoryConnected:(EAAccessory *)accessory;
-(void) onEAAccessoryDisConnected:(EAAccessory *)accessory;
-(void) regStateChanges;
-(void) unRegStateChanges;

@end
